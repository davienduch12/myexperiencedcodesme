<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>home</title>
<link rel="stylesheet" href="scripts/style.css" type="text/css" />
<script type="text/javascript" src="scripts/script.js"></script>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<?php
	include_once("library/config.php");
	include_once("library/lib.php");
	
	$message = "";
	$status = "true";	// determine if it returns true otherwise false.
	$error = array();
	$action = $_POST["actionflag"];
	$category = $_POST["category"];
	$description = $_POST["description"];
	if(isset($action) || $action == "categoryActive") {
		$category = trim($category);
		$description = trim($description);
		$category = mysql_real_escape_string($_POST["category"]);
		$description = mysql_real_escape_string($_POST["description"]);
		$category = stripslashes($category);
		$description = stripslashes($description);

		if(empty($category)) {
			$error["category"] .= "The category field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($description)) {
			$error["description"] .= "The category description field must have a value.<br>\n";	
			$status = "false";
		}
		if(getRow("category", "category", $category)) {
			$error["category"] .= "Category '$category' already exists. Try another one.<br>\n";
			$status = "false";
		}
		if($status == "true") {
			$message = addCategory($category, $description);
			$category = $_POST["category"] = "";
			$description = $_POST["description"] = "";
		}	
	}
?>
<body background="image/back_all1.png" onload="MM_preloadImages('image/home_btn_over.jpg','image/quiz_btn_over.jpg','image/exam_btn_over.jpg','image/student_btn_over.jpg','image/score_btn_over.jpg','image/logIn_btn_over.jpg')">
<table width="800" align="center" border="0" cellspacing="0" cellpadding="0">
  <tr align="center">
    <td><img src="image/image_final_02.jpg" width="100%" height="200" /></td>
  </tr>
  <tr>
    <td><table width="100%" background="image/bg_02.jpg" border="0" cellspacing="0" cellpadding="0">
	  <tr bgcolor="#53BC17" align="center" valign="middle">
		<td><img src="image/image_final_11.jpg" /></td>
		<td><a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image20','','image/home_btn_over.jpg',1)"><img src="image/create category .jpg" width="124" height="67" border="0" /></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><img src="image/create exam .jpg" width="124" height="67" /></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image22','','image/exam_btn_over.jpg',1)"><img src="image/create quiz .jpg" width="124" height="67" border="0" /></a><a href="exam.htm"></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image23','','image/student_btn_over.jpg',1)"><img src="image/settings.jpg" width="124" height="67" border="0" /></a><a href="student"></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image24','','image/score_btn_over.jpg',1)"><img src="image/report.jpg" width="124" height="67" border="0" /></a><a href="#"></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image25','','image/logIn_btn_over.jpg',1)"><img src="image/log_out.jpg" width="124" height="67" border="0" /></a><a href="#"></a></td>
		<td><img src="image/image_final_11.jpg" /></td>
	  </tr>
	  <tr>
	  	<td>&nbsp;</td>
	  	<td colspan="11">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  <tr valign="middle" height="10">
				<td width="10"><img src="image/left_curve.gif" /></td>
				<td width="*" background="image/top_edge.gif"></td>
				<td width="10"><img src="image/right_curve.gif" width="10" height="10" /></td>
			  </tr>
			  <tr bgcolor="#FFFFFF">
				<td background="image/left_edge.gif"></td>
				<td>
				<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
				<input name="actionflag" type="hidden" value="categoryActive" />
				<table align="center" border="0" cellspacing="0" cellpadding="4">
				  <?php if($message != "") { ?>
				  <tr valign="top">
					<td colspan="4" align="center" bgcolor="#33FF99">
						<?php	echo $message; ?>
					</td>
				  </tr>
				  <?php } ?>
				  <tr valign="top">
					<td>Category Name: </td>
					<td>&nbsp;  </td>
					<td><input name="category" type="text" id="category" value="<?php echo $_POST["category"]; ?>" size="30" /></td>
					<td class="error"><?php echo $error["category"]; ?></td>
					</tr>
				  <tr valign="top">
					<td>Category Description: </td>
					<td>&nbsp;  </td>
					<td><textarea name="description" cols="30" rows="3" wrap="virtual" id="description"><?php echo $_POST["description"]; ?></textarea></td>
					<td class="error"><?php echo $error["description"]; ?></td>
					</tr>
				  <tr>
					<td>&nbsp;</td>
					<td>&nbsp;  </td>
					<td><input type="submit" name="Submit" value="Submit" /></td><td><label></label></td>
					</tr>
				</table>
				</form>
				<table align="center" width="95%" border="0" cellspacing="2" cellpadding="2" class="content">
				  <tr>
					<th>Id</th>
					<th>Category</th>
					<th>Description</th>
					<th>Edit</th>
					<th>Delete</th>
				  </tr>
				<?php
					$tbl = "category";
					$count = 1;		// responsible for alternate colors of rows.
					$sql = "SELECT category_id, category, description FROM $tbl";
					$result = mysql_query($sql);
					if (!$result) {
						die("writeTableList fatal error: ".mysql_error());
						return false;
					}
					while ($row = mysql_fetch_row($result)) {	// returning an array containing each field in the row
						if($count%2 == 0)
							$bgcolor = "#E7E7E7";
						else
							$bgcolor = "#F5F5F5";
						echo "<tr bgcolor='$bgcolor' onmouseover='this.style.background=\"#CEFFCE\"' onmouseout='this.style.background=\"$bgcolor\"'>";
						for ($i = 0; $i < count($row); $i++)
						  echo " <td>$row[$i]</td> ";
						  echo " <td align=center><a href=\"edit.php?page=category&id=$row[0]\">edit</a></td> ";
						  echo " <td align=center><a href=\"delete.php?page=category&id=$row[0]\" onClick=\"if (!confirm('Do you really want to delete this record?')) return false;\">delete</a></td> ";	
						echo "</tr>";
						$count++;
					}
				
				?>
				</table>
				</td>
				<td background="image/right_edge.gif">&nbsp;</td>
			  </tr>
			  <tr>
				<td><img src="image/left_curve_below.gif" /></td>
				<td background="image/below_edge.gif"></td>
				<td><img src="image/right_curve_below.gif" /></td>
			  </tr>
			  <tr height="30">
				<td>&nbsp;</td>
				<td>
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="footer">
				  <tr align="center" valign="middle">
					<td><a href="#">&bull;our home</a></td>
					<td><a href="#">&bull;quiz</a></td>
					<td><a href="#">&bull;exam</a></td>
					<td><strong>&copy;Dream Team 2010</strong></td>
					<td><a href="#">&bull;student</a></td>
					<td><a href="#">&bull;score</a></td>
					<td><a href="#">&bull;log-in</a></td>
				  </tr>
				</table></td>
				<td>&nbsp;</td>
			  </tr>
			</table>
		  </td>
		<td>&nbsp;</td>
	  </tr>
	</table>
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>

</body>
</html>
