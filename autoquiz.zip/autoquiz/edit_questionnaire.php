<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<script type="text/javascript" src="scripts/script.js"></script>
<link type="text/css" href="scripts/style.css" rel="stylesheet" />
<style type="text/css">
<!--
.style1 {
	font-size: 10px;
	font-weight: bold;
}
-->
</style>
<?php
	include_once("library/config.php");
	include_once("library/lib.php");
	$message = "";
	$action = $_POST["actionflag"];
	$status = "true";
	$error = array();
	$qcode = $_POST["qcode"];
	$qno = $_POST["qno"];
		
	if(isset($action) || $action == "questionnaire") {
		if(empty($qcode)) {
			$error["qcode"] .= "The Questionnaire Code must have a value.<br>\n";
			$status = "false";
		}
		if(empty($qno)) {
			$error["qno"] .= "The Total Question Field must have a value.<br>\n";
			$status = "false";
		}	 
		if(strlen($qcode) < 6) {
			$error["qcode"] .= "Must be at least 6 characters.<br>\n";
			$status = "false";
		}	
		if(!ereg("^[0-9]{1,3}$", $qno)) {
			$error["qno"] .= "Must be a number.<br>\n";
			$status = "false";
		}
		if($qno > $_SESSION["totalQ"]) {
			$error["qno"] .= "No. of question(s) must be equal or less than the total of available question(s).<br>\n";
			$status = "false";
		}
		#if(getRow("questionnaire", "questionnaire_id", $qcode)) {
		#	$error["qcode"] .= "Questionnaire Code '$qcode' already exists. Try another one.<br>\n";
		#	$status = "false";
		#}
		if($status == "true") {
			$message = editQuestionnaire($qcode, $qno);
			$qcode = $_POST["qcode"] = "";
			$qno = $_POST["qno"] = "";
		}
	}
?>
</head>

<body><table align="center" width="50%" border="0" cellspacing="4" bgcolor="#CCCCCC" cellpadding="0">
  <tr>
    <td>
	<table width="100%" border="0" cellspacing="2" bgcolor="#FFFFFF" cellpadding="2">
	  <tr>
		<td colspan="2" bgcolor="#55FF55" align="center"><strong style="color:#330099">Q- Panel </strong></td>
	  </tr>
	  <tr>
		<th>Category</th>
		<th>Available Questions</th>
	  </tr>
	  <?php
		$show_category = mysql_query("SELECT * FROM category");
		while($show = mysql_fetch_array($show_category)) {
			echo "<tr align=center>";
			$show_total = mysql_query("SELECT DISTINCT COUNT(category_id) as total FROM question WHERE category_id='$show[category_id]' ");
			while($content = mysql_fetch_array($show_total)) {
				echo "<td>".$show["category"]."</td>";
				echo "<td>".$content["total"]."</td>";
			}
			echo "</tr>";
		}
		$get_total = mysql_query("SELECT COUNT(category_id) as availableQ FROM question");
		while($get_result = mysql_fetch_array($get_total)) { 
			$_SESSION["totalQ"] = $get_result[availableQ];
			echo "<tr>";
				echo "<td colspan=2 align=center><hr size=1>TOTAL QUESTIONS AVAILABLE: $get_result[availableQ]</td>";
			echo "</tr>";
		}
	  ?>
	</table>
	</td>
  </tr>
</table>
<br /><br />
<?php
	if($_GET["page"] == "questionnaire" || $_POST["SubmitQuestionnaire"]) {
		$show_data_questionnaire = mysql_query("SELECT * FROM questionnaire WHERE questionnaire_id='$_GET[id]' LIMIT 1");
		if($show_data_questionnaire) {
			while($data = mysql_fetch_array($show_data_questionnaire)) {
				$qcode = $data["questionnaire_id"];
				$qno = $data["questionnaire_total"];
			}
?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input name="actionflag" type="hidden" value="questionnaire" />
<input name="qcode" type="hidden" value="<?php echo $qcode; ?>" />
<table align="center" width="60%" border="0" cellspacing="2" cellpadding="4">
  <tr>
    <td colspan="2"><strong style="font-size:14px">Editing Questionnaire:</strong>
      <hr /></td>
  </tr> 
  <?php if($message != "") { ?>
  <tr valign="top">
	<td colspan="2" align="center" bgcolor="#33FF99">
		<?php	echo $message; ?>	</td>
  </tr>
  <?php } ?>
  <tr align="center">
  	<td>Enter the total number of question(s) to create:&nbsp;&nbsp;<input name="qno" type="text" id="qno" value="<?php echo $qno; ?>" size="2" maxlength="3" />
&nbsp; <span class="style1">(maximum of 3 integers)</span></td>
  	<td class="error"><?php echo $error["qno"];?></td>
  </tr>
  <tr>
  	<td align="center" colspan="2"><input name="SubmitQuestionnaire" type="submit" id="SubmitQuestionnaire" value="Submit" /></td>
  </tr>
</table>
</form>
<?php
		}
	}
?>
</body>
</html>
