<?php session_start(); ?>
<form action="" method="post">
<?php
	define("NL","<br>\n");
	require_once("library/config.php");
	if(!isset($_POST[set])) {
		$_SESSION["i"] = 0; 	// initialize the index;
	}
	if(isset($_POST[set])) {
		$sql = "select * from question WHERE flag !='1' ORDER BY RAND() LIMIT 1";
		$result = mysql_query($sql);
		
		$row = mysql_fetch_array($result); 
			echo $row[question].NL;
		$show_choice = mysql_query("SELECT * FROM choice WHERE choice_id='$row[question_id]'");
			while($show = mysql_fetch_array($show_choice)) {
				echo "<input name=\"choice[$_SESSION[i]]\" type=\"radio\" value=\"$show[choice_1]; ?>\">".$show["choice_1"].NL;
				echo "<input name=\"choice[$_SESSION[i]]\" type=\"radio\" value=\"$show[choice_2]; ?>\">".$show["choice_2"].NL;
				echo "<input name=\"choice[$_SESSION[i]]\" type=\"radio\" value=\"$show[choice_3]; ?>\">".$show["choice_3"].NL;
				echo "<input name=\"choice[$_SESSION[i]]\" type=\"radio\" value=\"$show[choice_4]; ?>\">".$show["choice_4"].NL;
				echo "<input name=\"answer[$_SESSION[i]]\" type=\"hidden\" value=\"$show[answer]; ?>\">".NL;
				$_SESSION[i] = $_SESSION[i] + 1;
			}
		if($_POST["submit"]) {
			$sl = "Update question set flag='1' where question_id='$row[question_id]'";
			$re = mysql_query($sl);	
		}
	}	
?>
	<input name="set" type="hidden" value="set">
	<?php if($_SESSION[counter] != 14) { ?>	
	<input name="submit" type="submit" value="Continue">
	<?php }?>
</form>
<?php
	if($_POST["submit"]) {
		if($_POST[choice] || $_POST[answer]) {	
			if($_POST[choice] == $_POST[answer]) {
				echo "Correct".NL;
				$_SESSION["correct"] = $_SESSION["correct"] + 1;
				echo "You have $_SESSION[correct] correct answer".NL;
			}
			else {
				echo "Incorrect".NL;
				$_SESSION["incorrect"] = $_SESSION["incorrect"] + 1;
				echo "You have $_SESSION[incorrect] incorrect answer".NL;
			}
		$_SESSION[counter] = $_SESSION[counter] + 1;
		}
		if($_SESSION[counter] == 14) {
			echo NL.NL.NL."TOTAL:".NL;
			echo "You have $_SESSION[correct] correct answer".NL;
			echo "You have $_SESSION[incorrect] incorrect answer".NL;
		}		
	}
	
?>