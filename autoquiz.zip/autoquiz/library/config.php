<?php
	define('HOST', 'localhost');
	define('USER', 'root');
	define('PWD', '');
	define('DB_NAME', 'autoquiz');
	define('QUESTION_TBL', 'question');
	define('CATEGORY_TBL', 'category');
	define('CHOICES_TBL', 'choices');
	define('STUDENT_TBL', 'students');
	define('QUESTIONNAIRE_TBL', 'questionnaire');
	
	mysql_connect("localhost","root","") or die("Couldn't connect to MySQL Server.");
	mysql_select_db("autoquiz") or die("Couldn't connect to database.");
?>