<?php
include_once("config.php");
	
function addQuestion($question, $category_id, $choice1, $choice2, $choice3, $choice4, $answer) {
	$query = "INSERT INTO ".QUESTION_TBL."(question, category_id) VALUES('$question', '$category_id')";
	$result = mysql_query($query) or die("Cannot insert into table " .QUESTION_TBL);
	if($result) {
		$insert_choices = "INSERT INTO ".CHOICES_TBL."(choice_1,choice_2,choice_3,choice_4,answer) VALUES('$choice1','$choice2','$choice3','$choice4','$answer')";
		$insert_result = mysql_query($insert_choices) or die("Cannot insert into table ".CHOICES_TBL);
	}
	if($insert_result)
		return "Success in inserting data";
}

function editQuestion($question_id, $question, $category_id, $choice1, $choice2, $choice3, $choice4, $answer) {
	$query = "UPDATE ".QUESTION_TBL." SET question='$question', category_id='$category_id' WHERE question_id='$question_id'";
	$result = mysql_query($query) or die("Cannot update into table " .QUESTION_TBL);
	if($result) {
		$edit_choices = "UPDATE ".CHOICES_TBL." SET choice_1='$choice1', choice_2='$choice2', choice_3='$choice3', choice_4='$choice4', answer='$answer' WHERE choice_id='$question_id'";
		$edit_result = mysql_query($edit_choices) or die("Cannot update into table ".CHOICES_TBL);
	}
	if($edit_result)
		return "Success in inserting data.<br>\n<a href='question.php'>back</a>";
}

function chooseOptions($tbl, $field) {
	$query = "SELECT $field as data FROM $tbl";
	$result = mysql_query($query) or die("Cannot insert into table " .CATEGORY_TBL);
	
	while($opt = mysql_fetch_array($result)) {
		echo "<option value=''>$opt[data]</option>";
	}
}

function addCategory($category, $description) {
	$query = "INSERT INTO ".CATEGORY_TBL."(category, description) VALUES('$category', '$description')";
	$result = mysql_query($query) or die("Cannot insert into table " .CATEGORY_TBL);
	if($result)
		return "Success in inserting data";
}

function editCategory($id, $category, $description) {
	$query = "UPDATE ".CATEGORY_TBL." SET category='$category', description='$description' WHERE category_id='$id' LIMIT 1";
	$result = mysql_query($query) or die("Cannot edit into table " .CATEGORY_TBL);
	if($result)
		return "Success in editing data.<br>\n<a href='category.php'>back</a>";
}

function addChoices($choice1, $choice2, $choice3, $choice4, $answer) {
	$query = "INSERT INTO ".CHOICES_TBL."(choice_1, choice_2, choice_3, choice_4, answer) VALUES('$choice1', '$choice2', '$choice3', '$choice4', '$answer')";
	$result = mysql_query($query) or die("Cannot insert into table " .CHOICES_TBL);
	if($result)
		return "Success in inserting data";
}

function addStudent($student_id, $fname, $lname, $age) {
	$query = "INSERT INTO ".STUDENT_TBL."(student_id, first_name, last_name, age) VALUES('$student_id', '$fname', '$lname', '$age')";
	$result = mysql_query($query) or die("Cannot insert into table " .STUDENT_TBL);
	if($result)
		return "Success in inserting data diba!!!. <br>\n<a href='student.php'>back</a>"; 
}



function editStudent($student_id, $fname, $lname, $age) {
	$query = "UPDATE ".STUDENT_TBL." SET first_name='$fname', last_name='$lname', age='$age' WHERE student_id='$student_id'";
	$result = mysql_query($query) or die("Cannot update into table " .STUDENT_TBL);
	if($result)
		return "Success in inserting data.<br>\n<a href='student.php'>back</a>";
}

function addQuestionnaire($qcode, $qno) {
	$query = "INSERT INTO ".QUESTIONNAIRE_TBL."(questionnaire_id, questionnaire_total) VALUES('$qcode', '$qno')";
	$result = mysql_query($query) or die("Cannot insert into table " .QUESTIONNAIRE_TBL);
	if($result)
		return "Success in inserting data";
}

function editQuestionnaire($qcode, $qno) {
	$query = "UPDATE ".QUESTIONNAIRE_TBL." SET questionnaire_total='$qno' WHERE questionnaire_id='$qcode'";
	$result = mysql_query($query) or die("Cannot update into table " .QUESTIONNAIRE_TBL);
	if($result)
		return "Success in editing data.<br>\n<a href='questionnaire.php'>back</a>";
}

function getRow($table, $fnm, $fval) {		// get the value in db.tbl to know if it's already exists.
	$sql = "SELECT * FROM $table WHERE $fnm='$fval'";
	$result = mysql_query($sql);
	if(!$result)
		die("getRow fatal error: ".mysql_error());
	return mysql_fetch_array($result);
}

function writeTableList($tbl) {
	$count = 1;		// responsible for alternate colors of rows.
	$sql = "SELECT * FROM $tbl";
	$result = mysql_query($sql);
	if (!$result) {
		die("writeTableList fatal error: ".mysql_error());
		return false;
	}
	while ($row = mysql_fetch_row($result)) {	// returning an array containing each field in the row
		if($count%2 == 0)
			$bgcolor = "#DDEEFF";
		else
			$bgcolor = "#FEFEFE";
		print "<tr bgcolor='$bgcolor' onmouseover='this.style.background=\"#FFDDAA\"' onmouseout='this.style.background=\"$bgcolor\"'>";
		for ($i = 0; $i < count($row); $i++)
			print " <td> $row[$i]</td> ";
		print "</tr>";
		$count++;
	}
}



function getMax($tbl, $id) {
	$maximum = mysql_query("SELECT COUNT($id) as max FROM $tbl");
	$max_result = mysql_fetch_array($maximum);	
	return $max_result[max];
}

function randomQuestions($lim, $chk_category) {
	$min = 1;
	$max = getMax(QUESTION_TBL, question_id);
	
	$get_question_id_sql = mysql_query("SELECT category_id, question_id AS q_id FROM ".QUESTION_TBL);
	
	$index = 0;
	while( $get_array = mysql_fetch_array($get_question_id_sql)) {
		$set_array[$index] = $get_array["q_id"];
		$index++;
	}
	
	shuffle($set_array);	// random the value of an array...
	// get the randomization of an array...
	for($i=0; $i<$lim /*count($set_array)*/ ; $i++) {
		echo $i + 1 . ".) ";	// set a number before the question. 
		$show_questions = mysql_query("SELECT * FROM ".QUESTION_TBL." WHERE question_id = '$set_array[$i]' ");
		while( $questions = mysql_fetch_array($show_questions) ) {
			echo $questions['question']."<br>\n";
			$show_choices = mysql_query("SELECT * FROM choices WHERE choice_id='$set_array[$i]'");
			while($choice = mysql_fetch_array($show_choices)) {
				$choices_arr = array($choice["choice_1"],$choice["choice_2"],$choice["choice_3"],$choice["choice_4"]);
				shuffle($choices_arr);		//random choices...
				// set the four random choices...
				echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"radio\" name=\"RadioGroup1\" value=\"radio\" /> A. ".$choices_arr[0]."<br>\n";
				echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"radio\" name=\"RadioGroup1\" value=\"radio\" /> B. ".$choices_arr[1]."<br>\n";
				echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"radio\" name=\"RadioGroup1\" value=\"radio\" /> C. ".$choices_arr[2]."<br>\n";
				echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"radio\" name=\"RadioGroup1\" value=\"radio\" /> D. ".$choices_arr[3]."<br>\n";
			}
		}
	}
}
?>