<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<script type="text/javascript" src="scripts/script.js"></script>
<link rel="stylesheet" href="scripts/style.css" type="text/css" />
</head>

<body>
<?php
	require_once("library/config.php");
	require_once("library/lib.php");
	$message = "";
	$status = "true";	// determine if it returns true otherwise false.
	$error = array();
	$action = $_POST["actionflag"];
	$qid = $_POST["qid"];
	$category = $_POST["category"];
	$question = $_POST["question"];
	$choice1 = $_POST["choice1"];
	$choice2 = $_POST["choice2"];
	$choice3 = $_POST["choice3"];
	$choice4 = $_POST["choice4"];
	$choiceGroup = $_POST["choiceGroup"];
	if(isset($action) || $action == "questionActive") {
		$category = trim($category);
		$question = trim($question);
		$choice1 = trim($choice1);
		$choice2 = trim($choice2);
		$choice3 = trim($choice3);
		$choice4 = trim($choice4);
		
		$category = mysql_real_escape_string($_POST["category"]);
		$question = mysql_real_escape_string($_POST["question"]);
		$choice1 = mysql_real_escape_string($_POST["choice1"]);
		$choice2 = mysql_real_escape_string($_POST["choice2"]);
		$choice3 = mysql_real_escape_string($_POST["choice3"]);
		$choice4 = mysql_real_escape_string($_POST["choice4"]);
		
		$category = stripslashes($category);
		$question = stripslashes($question);
		$choice1 = stripslashes($choice1);
		$choice2 = stripslashes($choice2);
		$choice3 = stripslashes($choice3);
		$choice4 = stripslashes($choice4);
		
		if(empty($category)) {
			$error["category"] .= "The category field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($question)) {
			$error["question"] .= "The question field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($choice1)) {
			$error["choice1"] .= "The first choice field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($choice2)) {
			$error["choice2"] .= "The second choice field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($choice3)) {
			$error["choice3"] .= "The third choice field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($choice4)) {
			$error["choice4"] .= "The fourth choice field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($choiceGroup)) {
			$error["choiceGroup"] .= "You must choose the correct answer.<br>\n";
			$status = "false";
		}
		#if(getRow("question", "question", $question)) {
		#	$error["question"] .= "Question '$question' already exists. Try another one.<br>\n";
		#	$status = "false";
		#}
		if(!empty($choiceGroup)) {
			switch($choiceGroup) {
				case 'A':
					$answer = $choice1;
					break;
				case 'B':
					$answer = $choice2;
					break;
				case 'C':
					$answer = $choice3;
					break;
				case 'D':
					$answer = $choice4;
					break;
			}
		}
		if($status == "true") {
			$message = editQuestion($qid, $question, $category, $choice1, $choice2, $choice3, $choice4, $answer);
			#$category = $_POST["category"] = "";
			$question = $_POST["question"] = "";
			$choice1 = $_POST["choice1"] = "";
			$choice2 = $_POST["choice2"] = "";
			$choice3 = $_POST["choice3"] = "";
			$choice4 = $_POST["choice4"] = "";
			$answer = "";
		}	
	} // end of actionflag....

	if($_GET["page"] == "question" || $_POST["SubmitQuestion"]) {	// display for question
		$show_data_question = mysql_query("SELECT * FROM question WHERE question_id='$_GET[id]' LIMIT 1");
		if($show_data_question) {
			while($data = mysql_fetch_array($show_data_question)) {
				$question_id = $data["question_id"];
				$question = $data["question"];
				$category_id = $data["category_id"];
				$show_data_choices = mysql_query("SELECT * FROM choices WHERE choice_id='$question_id'");
				if($show_data_choices) {
					while($data2 = mysql_fetch_array($show_data_choices)) { 
						$choice1 = $data2["choice_1"];
						$choice2 = $data2["choice_2"];
						$choice3 = $data2["choice_3"];
						$choice4 = $data2["choice_4"];
						$answer = $data2["answer"];
					}
				}
			}
?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input name="actionflag" type="hidden" value="questionActive" />
<input name="qid" type="hidden" value="<?php echo $question_id; ?>" />
<table border="0" cellspacing="0" cellpadding="4">
  <?php if($message != "") { ?>
  <tr valign="top">
	<td align="center" bgcolor="#33FF99">
		<?php	echo $message; ?>
	</td>
  </tr>
  <?php } ?>
  <tr valign="top">
    <td>Select the category of the question:&nbsp;&nbsp;<select name="category">
      <?php
			$query = "SELECT * FROM ".CATEGORY_TBL;
			$result = mysql_query($query) or die("Cannot SELECT into table " .CATEGORY_TBL);
			while($opt = mysql_fetch_array($result)) {
				echo "<option value='$opt[category_id]' ";
				if($opt["category_id"] == $category_id_question)
					echo " SELECTED ";
				echo ">$opt[category_id] - $opt[category]</option>";
			}
	  ?>
    </select><br />
      <span class="error"><?php echo $error["category"]; ?></span>	</td>
    </tr>
  <tr valign="top">
    <td><label>Your question goes here:<br />
      <textarea name="question" cols="45" rows="3" wrap="virtual"><?php echo $question; ?></textarea>
    </label><br />
	  <span class="error"><?php echo $error["question"]; ?></span>	</td>
    </tr>
  <tr valign="top">
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="choiceGroup" type="radio" value="A" />
    A:
      <label>
      <input name="choice1" type="text" id="choice1" size="30" value="<?php echo $choice1; ?>" />
      </label><br />
	  <span class="error"><?php echo $error["choice1"]; ?></span></td>
    </tr>
  <tr valign="top">
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="choiceGroup" type="radio" value="B" />
    B:
      <label>
      <input name="choice2" type="text" id="choice2" size="30" value="<?php echo $choice2; ?>" />
      </label><br />
      <span class="error"><?php echo $error["choice2"]; ?></span></td>
    </tr>
  <tr valign="top">
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="choiceGroup" type="radio" value="C" />
    C:
      <label>
      <input name="choice3" type="text" id="choice3" size="30" value="<?php echo $choice3; ?>" />
      </label><br />
      <span class="error"><?php echo $error["choice3"]; ?></span></td>
    </tr>
  <tr valign="top">
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="choiceGroup" type="radio" value="D" />
    D:
      <label>
      <input name="choice4" type="text" id="choice4" size="30" value="<?php echo $choice4; ?>" />
      </label><br />
	  <span class="error"><?php echo $error["choice4"]; ?></span></td>
    </tr>
  <tr valign="top">
    <td class="error" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $error["choiceGroup"]; ?></td>
    </tr>
  <tr>
    <td align="center"><label>
      <input type="submit" name="SubmitQuestion" value="Insert Data" />
    </label></td>
    </tr>
</table>
</form>
<?php
		}
	}
?>
</body>
</html>
