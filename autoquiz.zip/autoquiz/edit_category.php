<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<script type="text/javascript" src="scripts/script.js"></script>
<link rel="stylesheet" href="scripts/style.css" type="text/css" />
</head>

<body>
<?php
	include_once("library/config.php");
	include_once("library/lib.php");
	
	$message = "";
	$status_category = "true";	// determine if it returns true otherwise false.
	$error_category = array();
	$action_category = $_POST["actionflag_category"];
	$id_data = $_POST["id"];
	$category_data = $_POST["category"];
	$description_data = $_POST["description"];
	if(isset($action_category) || $action_category == "categoryEdit") {
		$category_data = trim($category_data);
		$description_data = trim($description_data);
		$category_data = mysql_real_escape_string($_POST["category"]);
		$description_data = mysql_real_escape_string($_POST["description"]);
		$category_data = stripslashes($category_data);
		$description_data = stripslashes($description_data);

		if(empty($category_data)) {
			$error_category["category"] .= "The category field must have a value.<br>\n";	
			$status_category = "false";
		}
		if(empty($description_data)) {
			$error_category["description"] .= "The category description field must have a value.<br>\n";	
			$status_category = "false";
		}
		#if(getRow("category", "category", $category)) {
		#	$error["category"] .= "Category '$category' already exists. Try another one.<br>\n";
		#	$status = "false";
		#}
		if($status_category == "true") {
			$_SESSION["id"] = $_GET["id"];
			$message = editCategory($id_data, $category_data, $description_data);
			$category_data = $_POST["category"] = "";
			$description_data = $_POST["description"] = "";
		}	
	}	// end for categoryEdit
?>
<?php
	if($_GET["page"] == "category" || $_POST["SubmitCategory"]) {
		$show_data_category = mysql_query("SELECT * FROM category WHERE category_id='$_GET[id]' LIMIT 1");
		if($show_data_category) {
			while($data = mysql_fetch_array($show_data_category)) {
				$category_id = $data["category_id"];
				$category = $data["category"];
				$description = $data["description"];
			}
?>
<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
  <input name="actionflag_category" type="hidden" value="categoryEdit" />
  <input name="id" type="hidden" value="<?php echo $category_id; ?>" />
  <table border="0" cellspacing="0" cellpadding="4">
    <?php if($message != "") { ?>
    <tr valign="top">
      <td colspan="4" align="center" bgcolor="#33FF99"><?php echo $message; ?>      </td>
    </tr>
    <?php } ?>
    <tr valign="top">
      <td>Category Name: </td>
      <td>&nbsp;</td>
      <td><input name="category" type="text" id="category" value="<?php echo $category; ?>" size="30" /></td>
      <td class="error"><?php echo $error_category["category"]; ?></td>
    </tr>
    <tr valign="top">
      <td>Category Description: </td>
      <td>&nbsp;</td>
      <td><textarea name="description" cols="30" rows="3" wrap="virtual" id="description"><?php echo $description; ?></textarea></td>
      <td class="error"><?php echo $error_category["description"]; ?></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><input type="submit" name="SubmitCategory" value="Submit" /></td>
      <td><label></label></td>
    </tr>
  </table>
</form>
<?php
		}// end of showing data
	}// end of page=category
?>
</body>
</html>
