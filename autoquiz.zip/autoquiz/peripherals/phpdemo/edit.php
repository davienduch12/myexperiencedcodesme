<?php
error_reporting(E_ALL ^ E_NOTICE);
require("config.php");
require("clause.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Edit</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="<?php print($CSS); ?>" />
</head>

<body>
<?php
function View()
	{
		require("config.php");
		require("database.php");
		require("validator.php");
		print("<h3 align=center>Editing record</h3>");
		$TableID = $_GET['table_id'];
		$RowID = $_GET['row_id'];
		$Fields = explode("@", $Tables[$TableID]);
		$MappedTables = GetMappedTables($TableID);
		$Mappings = GetMappedField($TableID);
		if($MappedTables[0] != "")
			{
				$qry = "select * from `$TableNames[$TableID]`";
				$Count = 0;
				$Counter = 1;
				foreach($MappedTables as $NewTable)
					{
						$qry .= ",`$NewTable`";
					};
				$qry .= " where (";
				foreach($Mappings as $Mapping)
					{
						if($Counter%2 == 1)
							{
								$qry .= $Mapping."=";
							}
						else
							{
								$qry .= $Mapping;
								if($Counter < sizeof($Mappings))
									{
										$qry .= " and ";
									};
								$Count++;
							};
						$Counter++;
					};
				$qry .= ")";
				if($_GET['desc'] == "TRUE")
					{
						$qry .= " order by `$TableNames[$TableID]`.`$_GET[sortby]` desc";
					}
				elseif($_GET['desc'] == "FALSE")
					{
						$qry .= " order by `$TableNames[$TableID]`.`$_GET[sortby]` asc";
					};
				     if(isset($_GET['pri'])&$RowID== -1)
				{

				   $clause = stripslashes($_GET['pri']);
				   $clause = str_replace("%20"," ",$clause);
				   $clause = prepare_clause($clause);
  					 $qry .= " and $clause";
				}
					ELSE {

				      $qry .= " limit $RowID,1";
				      }

			}
		else
			{
				$qry = "select * from `$TableNames[$TableID]`";
				if($_GET['desc'] == "TRUE")
					{
						$qry .= " order by `$TableNames[$TableID]`.`$_GET[sortby]` desc";
					}
				elseif($_GET['desc'] == "FALSE")
					{
						$qry .= " order by `$TableNames[$TableID]`.`$_GET[sortby]` asc";
					};
				if(isset($_GET['pri'])&$RowID== -1)

				{

				   $clause = stripslashes($_GET['pri']);
				   $clause = str_replace("%20"," ",$clause);
				   $clause = prepare_clause($clause);
  					 $qry .= " where $clause";


				}
					ELSE
     			 {
				      $qry .= " limit $RowID,1";
				 }
				//echo $qry;
			};
		print("<table align=center class=Table>");
		echo '<form action="edit.php" method="post">';
		$Result = mysql_query($qry);
		$Raw = mysql_fetch_array($Result);
		foreach($Fields as $Field)
			{
				print("<tr class=TableAltRow>");
				$TempName = "Old".$Field;
				$TempValue = $Raw[$Field];
				echo '<input type="hidden" name="';print($TempName);echo '" value="';print($TempValue);echo '">';
				print("<td>$Field</td>");
				if (strlen($Raw[$Field])<40)
				{
				echo '<td><input type="text" name="';print($Field);echo '" value= "';print($Raw[$Field]) ;echo '" size="50" ></td>';
				//echo "<td>$Raw[$Field]</td>";
				}
				else
				{
				echo '<td><textarea name="';print($Field);echo '" value="';echo '" cols="39" rows="4"  >';print($Raw[$Field]);echo '</textarea></td>';				}
				print("<tr>");
			};
		print("<input type=hidden name=table_id value=$TableID>");
		echo '<tr><td><input type="submit" name="Action" value="Edit"></td></tr>';
		echo '</form>';
		print("</table>");
	};
function Save()
	{
		require("config.php");
		require("database.php");
		require("validator.php");
		$TableID = $_POST['table_id'];
		$Fields = explode("@", $Tables[$TableID]);
		$QUERY = "update `$TableNames[$TableID]` set ";
		$FieldCounter = 0;
		foreach($Fields as $Field)
			{
				$FieldCounter++;
				if(Validate($TableID, $Field, $_POST[$Field]) == "false")
					{
						$ProperField = $Field;
						$TMP = explode(" ", $Field);
						if($TMP[1] != "")
							{
								$ProperField = str_replace(" ", "_",$Field);
							};
						$QUERY .= "`$TableNames[$TableID]`.`$Field`='".$_POST[$ProperField]."'";
					}
				else
					{
						die("The value `$_POST[$Field]` at `$Field` in table `$TableName[$TableID]` is not accepted");
					};
				if(sizeof($Fields) > $FieldCounter)
					{
						$QUERY .= ", ";
					};
			};
		$QUERY .= " where ";
		$FieldCounter = 0;
		foreach($Fields as $Field)
			{
				$Temp = "Old".$Field;
				$SpaceCHK = explode(" ", $_POST[$Temp]);
				$FloatCheck = explode(".", $_POST[$Temp]);
				$Float = false;
				if(is_numeric($_POST[$Temp]) && $FloatCheck[1] != "")
					{
						$Float = true;
					};
				if($_POST[$Temp] != "" && $SpaceCHK[1] == "" && !$Float)
					{
						$FieldCounter++;
						if($FieldCounter > 1)
							{
								$QUERY .= " and ";
							};
						$QUERY .= "`$Field`"."='".$_POST[$Temp]."'";
					};
			};
		//print($QUERY);
		mysql_unbuffered_query($QUERY);
		if(mysql_error() == "")
			{
				print("<H3 align=center>Edit successfull</H3>");
				echo '<p align=center><a href="main.php?table_id=';print($TableID);echo'">Home</a></p>';
			}
		else
			{
				print(mysql_error());
			};
	};

if($_GET['action'] == "Edit" && $_POST['Action'] == "")
	{
		View();
	}
elseif($_POST['Action'] == "Edit")
	{
		Save();
	};

?>
</body>
</html>
