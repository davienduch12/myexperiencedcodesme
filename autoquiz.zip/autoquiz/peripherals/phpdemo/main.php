<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);

require("config.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Table Admin</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link rel="stylesheet" type="text/css" href="<?php print($CSS); ?>" />
</head>

<body>
<table align="left" cellpadding="10" cellspacing="10">
<tr>
<td width="200" valign="top" align="left"><?php require("tablelist.php");?></td>
<td align="center">
<table align="center" cellpadding="3" cellspacing="3">
<?php
require("database.php");
$TableID = $_GET['table_id'];
if($TableID == "")
	{
		?>
		<p align="center">You must select a table before proceeding</p>
		<p align="center"><a href="index.php">Home</a></p>
		<?php
		die();
	};
if($Admin != "" && $_SESSION['logged'] == "")
	{
			?>
			<SCRIPT LANGUAGE="JavaScript">
			function delayer(){
			window.location = "index.php"
				}
			</script>
		<?php
		die("You are not allowed to view this");
	};
//display headers      ?>
<TR>
         <TR>
          <TD align=middle width="694">
            <p><b><font size="4">Table :</font></b><font size="4">
			</font><b><font size="4" color="#000080"><?php echo $TableNames[$TableID]; ?></font></b><u></TD>
          </TR>


<?php
if($Search == "true")
	{
		print("<tr><td align=center><h3>Search in the records</h3></td></tr>");
		print("<tr><td>");
		require("search.php");
		print("</td></tr><tr><td><hr></td></tr>");
	};
if($View == "true")
	{
		print("<tr><td align=center><h3>View Records</h3></td></tr>");
		print("<tr><td>");
		require("view.php");
		print("</td></tr>");
		print("<tr><td><hr></td></tr>");
	};
if($Add == "true")
	{
		print("<tr><td align=center><h3>Add A Record</h3></td></tr>");
		print("<tr><td>");
		require("add.php");
		print("</td></tr>");
	};
?>
</table>
</td></tr>
</table>

<?php




?>
</body>
</html>
