<?php
error_reporting(E_ALL ^ E_NOTICE);
require("config.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Query Execution</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="<?php print($CSS); ?>" />
</head>

<body>
<?php
require("database.php");
$QueryID = $_GET['query_id'];
$QUERY = $ExtraQueryes[$QueryID];
$Temp = explode(" ", $QUERY);
?>
<h3 align="center">Successfully Executed Selected Query</h3>
<p align="center"><a href="index.php">Home</a></p>
<?php
if(strtolower($Temp[0]) == "select")
	{
		$Result = mysql_query($QUERY);
		if(mysql_error() != "")
			{
				die("MySQL returned : ".mysql_error());
			};
		print("<h4 align=center>MySQL Returned : </h4>");
		while($Raw = mysql_fetch_array($Result))
			{
				$Keys = array_keys($Raw);
				$Counter = 0;
				foreach($Raw as $Tmp)
					{
						if(!is_numeric($Keys[$Counter]))
							{
								print("<p align=center>$Keys[$Counter] = $Tmp</p>" );
							};
						$Counter++;
					};
					print("<hr>");
			};
	}
else
	{
		mysql_unbuffered_query($QUERY);
	};
?>
</body>
</html>
