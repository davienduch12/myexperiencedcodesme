<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require("config.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Start Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="<?php echo $CSS; ?>" />
</head>

<body>
<h3 align="center">Please select a table to work with</h3>
<?php
if($Admin != "" && $_SESSION['logged'] == "")
	{
		?>
		<table align="center" cellpadding="2" cellspacing="2">
		<form action="login.php" method="post">
		<tr><td>Username </td><td><input type="text" name="USERNAME"></td></tr>
		<tr><td>Password </td><td><input type="password" name="PASSWORD"></td></tr>
		<tr><td>&nbsp;</td><td><input type="submit" name="ACTION" value="Login"</td></tr>
		</form>
		</table>
		<?php
		die();
	};


?>
<table align="center">
<tr><td align="left" valign="top" width="200"><?php require("tablelist.php"); ?></td>
<td align="center" valign="top">
<h3 align="center">Home Page</h3>

</td></tr></table>
</body>
</html>
