<?php
$TableData['0@category_id'] = "0    0       1";
$TableData['0@category'] = "0    0       1";
$TableData['0@description'] = "0    0       1";
$Tables['0'] = "category_id@category@description";
$TableNames['0'] = "category";
$FKInfo['0'] = "";
$Delete = True;
$Add = True;
$Edit = True;
$Search = True;
$View = True;
$ViewTable = False;
$Form = False;
$SearchRecords = True;
$PHPValidate = True;
$JavaValidate = False;
$Navigator = False;
$RecsPerPage = 10;
$Admin = "root";
$AdminPass = "";
$FK = False;
$CSS = "default.css";
$d = True
?>
