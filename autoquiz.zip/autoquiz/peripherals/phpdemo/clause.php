<?php
function prepare_clause($str)
{

  $arr1 = explode("and",$str);
  foreach ($arr1 as $val1)
 {	    $arr2 = explode("=",$val1);
	    $temp = "";
	    foreach($arr2 as $val2)
	    {
	        $val2 = trim($val2);
	        $x = strpos($val2,"'");
	        $y = strrpos($val2,"'");
	        if($x == 0 & $y == strlen($val2)-1)
	         {
	             $val2 = substr($val2,1,strlen($val2)-2);	        }
	       $val2 = addslashes($val2);

          if(empty($temp))
         {          	$temp = $val2;
         }         else
         {
         $temp .= " = '".$val2."'";         }
	 }
       $constrains[] = $temp; }
    $constrain = implode($constrains," and ");
    return $constrain;
}
?>