
<?php
require("config.php");
error_reporting(E_ALL ^ E_NOTICE);
$TableID = $_GET['table_id'];
$Fields = explode("@", $Tables[$TableID]);
print("<table align=center class=Table>");
print("<form action=searchres.php method=post>");
print("<tr><td><input type=text name=QUERY></td></tr>");
print("<input type=hidden name=table_id value=$TableID>");
print("<tr><td><input type=submit name=action value=Search></td></tr>");
print("</form>");
print("</table>");
?>
