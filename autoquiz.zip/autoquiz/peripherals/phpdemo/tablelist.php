<?php
require("config.php");
print("<table align=center>");
?>
<STYLE>
	a:hover{color:red;};
</STYLE>
<tr><td><a href="index.php">Home</a></td></tr>
<?php
$Counter = 0;
foreach($TableNames as $Table)
	{
		?>
		<tr><td><a href="main.php?table_id=<?php echo $Counter;?>&Action=Go"><?php echo $Table;?></a></td></tr>
		<?php
		$Counter++;
	};
	if($d==true)
	{_
	?>
	<tr><td><a href="http://softgalaxy.net/php-mysql/Order.html">order now</a></td></tr>
		<?php
	}

print("</table>");



?>