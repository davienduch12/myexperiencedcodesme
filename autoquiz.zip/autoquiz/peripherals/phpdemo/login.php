<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require("config.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Logging In...</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="<?php print($CSS); ?>" />
</head>

<body onLoad="setTimeout('delayer()', 3000)">
<?php
if($_POST['USERNAME'] == $Admin && $_POST['PASSWORD'] == $AdminPass)
	{
		$_SESSION['logged'] = "true";
		?>
			<SCRIPT LANGUAGE="JavaScript">
			function delayer(){
			window.location = "index.php"
				}
			</script>
			Login OK, Please wait...
		<?php
	}
else
	{
		print("Login failed");
		?>
		<SCRIPT LANGUAGE="JavaScript">
			function delayer(){
			window.location = "index.php"
				}
			</script>
		
		<?php
	};


?>
</body>
</html>
