<?php
error_reporting(E_ALL ^ E_NOTICE);
require("config.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Results</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="<?php print($CSS); ?>" />
</head>

<body>
<table align="left">
<tr valign="top"><td valign="top" width="200" align="left"><?php require("tablelist.php");?></td><td align="center" valign="top">
<?php
require_once("database.php");
$TableID = $_POST['table_id'];
$Fields = explode("@", $Tables[$TableID]);

// get the primary key and check that it is selected in the $fields
require_once("primary.php");
$PRS = get_primary($TableNames[$TableID]);


$QUERY = "select * from `$TableNames[$TableID]` where ";
$Counter = 0;
foreach($Fields as $Field)
	{
		$Counter++;
		if($Counter > 1)
			{
				$QUERY .= " or ";
			};
		$QUERY .= "`$Field` like '%$_POST[QUERY]%'";
	};
print("<h3 align=center>Search Results</h3>");
$Result = mysql_query($QUERY);
print(mysql_error());
print("<table align=center class=Table>");
print("<tr class=Header>");
foreach($Fields as $Field)
	{
		print("<td><b>$Field</b></td>");
	};
	print("<td><b>Edit</b></td>");
    //print("<td><b></b></td>");
    print("<td><b>Delete</b></td>");
print("<tr>");
$ResultCounter = 0;
while($Raw = mysql_fetch_array($Result))
{
		print("<tr class=TableAltRow>");
		$temp = "";
	foreach($Fields as $Field)
	{
			 if (count($PRS)!=0)
			 {

			  if(in_array($Field,$PRS))
			  {
			    	  if(empty($temp))
			    	  {
			    	    $temp = "$Field = '".$Raw[$Field]."'";
			    	  }

			    	 else

			    	  {
			    	 $temp .=   " and $Field = '".$Raw[$Field]."'";
			    	  }			  }



			 }

	print("<td>$Raw[$Field]</td>");

    };


	  	if(count($PRS) != 0)
		 	{
				?>
				<td><a href="edit.php?action=Edit&table_id=<?php echo $TableID;?>&row_id=<?php  echo '-1'; ?> &pri=<?php  echo $temp;  ?>" > Edit </a></td>


				<td><a href="delete.php?action=Delete&table_id=<?php echo $TableID;?>&row_id=<?php echo '-1'; ?>&pri=<?php  echo $temp;  ?>">Delete</a></td>
				<?php
	  		}
	  		ELSE
	  		{	  			echo"<td></td> <td></td>";
	  		}
		$ResultCounter++;
		print("</tr>");
};
?>
</table>
<?php

  if (count($PRS)==0)
   {
     echo "<p align='center'><font color='#000080'><i>There is no primary
		key or it�s not selected among the columns you selected from the $TableNames[$TableID]
		table, you need to create or select a primary key to be able to edit and delete
		search results.</i></font></p>";   }

?>
<p align="center"><a href="index.php">Home</a></p>
</td></tr></table>
</body>
</html>