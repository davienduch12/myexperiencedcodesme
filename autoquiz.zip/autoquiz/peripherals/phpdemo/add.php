
<?php
error_reporting(E_ALL ^ E_NOTICE); 

function Basic()
	{
		require("database.php");
		require("config.php");
		require_once("validator.php");
		$TableID = $_GET['table_id'];
		//print("<h3 align=center>Adding Records to $TableNames[$TableID]</h3>");
		print("<table align=center class=Table>");
		$Fields = explode("@", $Tables[$TableID]);
		echo '<form action="add.php" method="POST">';
		
		$Counter = 0;
		$care = 0;
		$MappedTable = GetMappedTables($TableID);
		foreach($Fields as $Field)
			{
				$flags = array();
				$qry = "select `$Field` from $TableNames[$TableID]";
				$result = mysql_query($qry);
				if($result)
					{
						$flags = mysql_field_flags($result, 0);
						$flags = explode(' ', $flags);
					};
				$MappedField = GetMapping($TableID, $Field);
				$Temp = explode(".", $MappedField);
				if($MappedField != $Field && $Temp[0] != $TableNames[$TableID] && $Temp[1] != "")
					{
						$Tmp = explode('.', $MappedField);
						if($Tmp[1] == "")	
							{
								$Tmp = $Tmp[0];
								$MappedTable[0] = $TableNames[$TableID];
							}
						else
							{
								$Tmp = $Tmp[1];
							};
						$qry = "select `$Tmp` from `$MappedTable[$Counter]`";
						$Result = mysql_query($qry);
						print("<tr class=TableAltRow><td>$Tmp</td><td><select name=$Field>");
						while($Raw = mysql_fetch_array($Result))
							{
								echo '<option value="';print($Raw[$Tmp]);echo '">';print($Raw[$Tmp]."</option>");
							};
						print("</select></td></tr>");
						$care = 1;
						$Counter++;
					};
				if(!in_array('auto_increment', $flags) && $care == 0)
					{
						print("<tr class=TableAltRow>");
						print("<td>$Field</td><td>");echo '<input type="text" name="';print($Field);echo '"></td>';
						print("</tr>");
					};
				$care = 0;
			};
		print("<tr class=TableAltRow><td><input type=submit name=action value=Add></td><td>&nbsp;</td></tr>");
		print("<input type=hidden name=table_id value=$TableID>");
		print("</form>");
	};
function Add()
	{
		require("database.php");
		require("config.php");
		require("validator.php");
		?>
		<link rel="stylesheet" type="text/css" href="<?php print($CSS); ?>" />
		<?php
		$TableID = $_POST['table_id'];
		$Fields = explode("@", $Tables[$TableID]);
		$QUERY = "insert into `$TableNames[$TableID]`(";
		$FieldCounter = 0;
		foreach($Fields as $Field)
			{
				$FieldCounter++;
				$QUERY .= "`".$Field."`";
				if($FieldCounter < sizeof($Fields))
					{
						$QUERY .= ", ";
					}
				else
					{
						$QUERY .= ") values(";
					};
			};
		$FieldCounter = 0;
		foreach($Fields as $Field)
			{
				$FieldCounter++;
				if(Validate($TableID, $Field, $_POST[$Field]) == "false")
					{
					if($Field != GetMapping($TableID,$Field))
						{
							$Temp = GetMapping($TableID, $Field);
							$Mapped = explode(".", $Temp);
							$Key = $Field;
							if(!FieldExists("`$Mapped[0]`.`$Field`"))
								{
									$Key = GetCorrectKey($Mapped[0],$Field);
									$qry = "select * from `$Mapped[0]` where `$Mapped[1]`='$_POST[$Field]'";
								}
							else
								{
									$qry = "select * from `$Mapped[0]` where `$Mapped[1]`='$_POST[$Field]'";
								};
							$Result = mysql_query($qry);
							$Raw = mysql_fetch_array($Result);
							$Key = trim($Key);
							$QUERY .= "'".$Raw[$Key]."'";
						}
					else
						{
							$TMP = explode(" ", $Field);
							if($TMP[1] != "")
								{
									$Field = str_replace(" ", "_", $Field);
								};
							$QUERY .= "'".$_POST[$Field]."'";
						};
					}
				else
					{
						die("The value $_POST[$Field] at $Field in table $TableName[$TableID] is not accepted");
					};
				if($FieldCounter < sizeof($Fields))
					{
						$QUERY .= ", ";
					}
				else
					{
						$QUERY .= ")";
					};
			};
	//	print($QUERY);
		mysql_unbuffered_query($QUERY);
		if(!mysql_error())
			{
				print("<H3 align=center>Added Successfully</H3>");
			}
		else
			{
				print("<H3 aclign=center>Addition failed : ".mysql_error()."</H3>");
			};
		echo '<p align=center><a href="main.php?table_id=';print($TableID);echo'">Home</a></p>';
	};
if($_POST['table_id'] == "" && $_GET['table_id'] != "")
	{
		Basic();
	}
elseif($_POST['table_id'] != "")
	{
		Add();
	};
?>
