<?php
require("database.php"); 
require("config.php");
require("validator.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>View Full Row</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="<?php print($CSS); ?>" />
</head>

<body>
<table align="center">
<tr><td align="left" valign="top"><?php require("tablelist.php");?></td>
<td align="center" valign="top">
<?php
$TableID = $_GET['table_id'];
$MappedTables = GetMappedTables($TableID);
$Mappings = GetMappedField($TableID);
$RowID = $_GET['row_id'];
$Fields = explode("@", $Tables[$TableID]);
if($MappedTables[0] != "")
	{
		$qry = "select * from `$TableNames[$TableID]`";
				$Count = 0;
				$Counter = 1;
				foreach($MappedTables as $NewTable)
					{
						$qry .= ",`$NewTable`";
					};
				$qry .= " where (";
				foreach($Mappings as $Mapping)
					{
						if($Counter%2 == 1)
							{
								$qry .= $Mapping."=";
							}
						else
							{
								$qry .= $Mapping;
								if($Counter < sizeof($Mappings))
									{
										$qry .= " and ";
									};
								$Count++;
							};
						$Counter++;
					};
				$qry .= ")";
		if($_GET['desc'] == "TRUE")
			{
				$qry .= " order by `$TableNames[$TableID]`.$_GET[sortby] desc";
			}
		elseif($_GET['desc'] == "FALSE")
			{
				$qry .= " order by `$TableNames[$TableID]`.$_GET[sortby] asc";
			};
		$qry .= " limit $RowID,1";
	}
else
	{
		$qry = "select * from `$TableNames[$TableID]`";
		if($_GET['desc'] == "TRUE")
			{
				$qry .= " order by `$TableNames[$TableID]`.$_GET[sortby] desc";
			}
		elseif($_GET['desc'] == "FALSE")
			{
				$qry .= " order by `$TableNames[$TableID]`.$_GET[sortby] asc";
			};
		$qry .= " limit $RowID,1";
	};
$Result = mysql_query($qry);
$ResCounter = 0;
print("<table class=Table>");
print("<tr class=Header>");
foreach($Fields as $Field)
	{
		print("<td><b>$Field</b></td>");
	};
print("<td><b>&nbsp;</b></td>");
print("<td><b>&nbsp;</b></td>");
print("</tr>");
$Raw = mysql_fetch_array($Result);
print("<tr class=TableAltRow>");
foreach($Fields as $Field)
	{
		if(GetMapping($TableID,$Field) == $Field)
			{
				print("<td>$Raw[$Field]</td>");
			}
		else
			{
				$TMP = trim(GetMapping($TableID,$Field));
				$TMP = explode(".", $TMP);
				$TMP = $TMP[1];
				if($TMP == "")
					{
						$TMP = GetMapping($TableID, $Field);
					};
				print("<td>$Raw[$TMP]</td>");
			};	
	};
	if($Edit == "true")
		{
			?>
			<td><a href="edit.php?action=Edit&table_id=<?php echo $TableID;?>&row_id=<?php echo $_GET['row_id'];?>
			<?php
				if($_GET['desc'] != "")
					{
						print("&sortby=$_GET[sortby]&desc=$_GET[desc]");
					};
			?>
			">Edit</a></td>
			<?php
		};
	if($Delete == "true")
		{
			?>
			<td><a href="delete.php?action=Delete&table_id=<?php echo $TableID;?>&row_id=<?php echo $_GET['row_id'];?>
			<?php
				if($_GET['desc'] != "")
					{
						print("&sortby=$_GET[sortby]&desc=$_GET[desc]");
					};
			?>
			">Delete</a></td>
			<?php
		};				
	print("</tr>");
?>

</td>
</tr>
</table>
</body>
</html>
