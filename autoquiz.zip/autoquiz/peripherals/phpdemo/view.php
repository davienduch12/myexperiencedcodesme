<?php
error_reporting(E_ALL ^ E_NOTICE); 
require("config.php");
require("validator.php");
require("database.php");
$MappedTables = GetMappedTables($TableID);
$Mappings = GetMappedField($TableID);
if(sizeof($MappedTables) > 0)
	{
		$qry = "select * from `$TableNames[$TableID]`";
		$Count = 0;
		$Counter = 1;
		foreach($MappedTables as $NewTable)
			{
				$qry .= ",`$NewTable`";
			};
		$qry .= " where (";
		foreach($Mappings as $Mapping)
			{
				if($Counter%2 == 1)
					{
						$qry .= $Mapping."=";
					}
				else
					{
						$qry .= $Mapping;
						if($Counter < sizeof($Mappings))
							{
								$qry .= " and ";
							};
						$Count++;
					};
				$Counter++;
			};
		$qry .= ")";
		$GLQRY = $qry;
		$Result2 = mysql_query($qry);
	}
else
	{
		$qry = "select * from `$TableNames[$TableID]`";
		$Result2 = mysql_query($qry);
	};
	//print($qry);
$Total = 0;
while($Raw = mysql_fetch_array($Result2))
	{
		$Total++;
	};
$Total = floor($Total / $RecsPerPage);
$Fields = explode("@", $Tables[$TableID]);
$PageID = $_GET['page_id'];
if($PageID == "" && !is_numeric($PageID)) {$PageID = 0;};
$StartFrom = $PageID*$RecsPerPage;
$ResultCounter = $StartFrom;
$NewID = $PageID + 1;
$OldID = $PageID - 1;
$StepID = $PageID + 1;
$Limit = $RecsPerPage;
if($Limit < 2)
	{
		$Limit = 100;
	};
if($_GET['desc'] == "TRUE")
	{
		if($MappedTables[0] != "")
			{
				//$qry = "select * from `$TableNames[$TableID]` join `$MappedTables[0]` on `$MT[0]`.$MF[0]=`$MT[1]`.$MF[1]";
				$qry = $GLQRY;
				$qry .= " order by `$TableNames[$TableID]`.`$_GET[sortby]` desc limit $StartFrom, $Limit";
			}
		else
			{
				$qry = "select * from `$TableNames[$TableID]` order by `$_GET[sortby]` desc limit $StartFrom, $Limit";
			};
	//	print($qry);
		$Result = mysql_query($qry);
	}
else
	{
		if($_GET['sortby'] != "")
			{
				if($MappedTables[0] != "")
					{
						//$qry = "select * from `$TableNames[$TableID]` join `$MappedTables[0]` on `$MT[0]`.$MF[0]=`$MT[1]`.$MF[1]";
						$qry = $GLQRY;
						$qry .= " order by `$TableNames[$TableID]`.`$_GET[sortby]` limit $StartFrom, $Limit";
					}
				else
					{
						$qry = "select * from `$TableNames[$TableID]` order by `$_GET[sortby]` limit $StartFrom, $Limit";
					};
			}
		else
			{
				if($MappedTables[0] != "")
					{
						//$qry = "select * from `$TableNames[$TableID]` join `$MappedTables[0]` on `$MT[0]`.$MF[0]=`$MT[1]`.$MF[1]";
						$qry = $GLQRY;
						$qry .= " limit $StartFrom, $Limit";
					}
				else
					{
						$qry = "select * from `$TableNames[$TableID]` limit $StartFrom, $Limit";
					};
			};
		//print($qry);
		$Result = mysql_query($qry);
	};
if(mysql_error() != "")
	{
		die("An error has occured: ".mysql_error());
	};
print("<table align=center class=Table>");
print("<tr class=Header>");
if(sizeof($Fields) >= 5)
	{
		for($Counter = 0;$Counter <= 5;$Counter++)
				{
					$Field = $Fields[$Counter];
					print("<td>");
					print("<b>$Field</b>&nbsp;");
					?>
					<a href="main.php?desc=TRUE&table_id=<?php echo $TableID;?>&sortby=<?php echo $Field;?>">
					<IMG src="down.gif" border="0"></a>
					<a href="main.php?desc=FALSE&table_id=<?php echo $TableID;?>&sortby=<?php echo $Field;?>">
					<IMG src="up.gif" border="0"></a>
					<?php
					print("</td>");
				};
		print("<td><b>&nbsp;</b></td>");
	}
else
	{
		foreach($Fields as $Field)
			{
				print("<td>");
				print("<b>$Field</b>&nbsp;");
				?>
				<a href="main.php?desc=TRUE&table_id=<?php echo $TableID;?>&sortby=<?php echo $Field;?>">
				<IMG src="down.gif" border="0"></a>
				<a href="main.php?desc=FALSE&table_id=<?php echo $TableID;?>&sortby=<?php echo $Field;?>">
				<IMG src="up.gif" border="0"></a>
				<?php
				print("</td>");
			};
	};
if($Edit == true && $Delete == true)
	{
		print("<td><b>&nbsp;</b></td>");
		print("<td><b>&nbsp;</b></td>");
	}
elseif($Edit == true || $Delete == true)
	{
		print("<td><b>&nbsp;</b></td>");
	};
print("</tr>");
while($Raw = mysql_fetch_array($Result))
	{
		print("<tr class=TableAltRow>");
		if(sizeof($Fields) >= 5)
			{
				for($Counter = 0;$Counter <= 5;$Counter++)
					{
						$Field = $Fields[$Counter];
						if(GetMapping($TableID,$Field) == $Field)
							{
								print("<td>$Raw[$Field]</td>");
							}
						else
							{
								$TMP = GetMapping($TableID,$Field);
								$TMP = explode(".", $TMP);
								$TMP = $TMP[1];
								if($TMP == "")
									{
										$TMP = GetMapping($TableID, $Field);
									};
								print("<td>$Raw[$TMP]</td>");
							};	
					};
				?>
				<td><a href="advview.php?action=showall&table_id=<?php echo $TableID;?>&row_id=<?php echo $ResultCounter;?>
				<?php
					if($_GET['desc'] != "")
						{
							print("&desc=$_GET[desc]");
						};
					if($_GET['sortby'] != "")
						{
							print("&sortby=$_GET[sortby]");
						};
				
				?>
				">View</a></td>
				<?php
			}
		else
			{
				foreach($Fields as $Field)
					{
						if(GetMapping($TableID,$Field) == $Field)
							{
								print("<td>$Raw[$Field]</td>");
							}
						else
							{
								$TMP = trim(GetMapping($TableID,$Field));
								$TMP = explode(".", $TMP);
								$TMP = $TMP[1];
								if($TMP == "")
									{
										$TMP = GetMapping($TableID, $Field);
									};
								print("<td>$Raw[$TMP]</td>");
							};		
					};
			};
		if($Edit == "true")
			{
				?>
				<td><a href="edit.php?action=Edit&table_id=<?php echo $TableID;?>&row_id=<?php echo $ResultCounter;?>
				<?php
					if($_GET['sortby'] != "")
						{
							print("&sortby=$_GET[sortby]&desc=$_GET[desc]");
						};
				?>
				">Edit</a></td>
				<?php
			};
		if($Delete == "true")
			{
				?>
				<td><a href="delete.php?action=Delete&table_id=<?php echo $TableID;?>&row_id=<?php echo $ResultCounter;?>
				<?php
					if($_GET['sortby'] != "")
						{
							print("&sortby=$_GET[sortby]&desc=$_GET[desc]");
						};
				?>
				">Delete</a></td>
				<?php
			};			
			$ResultCounter++;	
print("</tr>");
	};
print("<tr>");
$Limit = $StartFrom + $RecsPerPage-1;
if($_GET['desc'] == "TRUE")
	{
		$NewLimit = ++$Limit;
		$QUERY = "select * from `$TableNames[$TableID]` order by `$_GET[sortby]` desc limit $Limit, $NewLimit";
		$Result = mysql_query($QUERY);
	}
else
	{
		if($_GET['sortby'] != "")
			{
				$NewLimit = ++$Limit;
				$QUERY = "select * from `$TableNames[$TableID]` order by `$_GET[sortby]` limit $Limit, $NewLimit";
				$Result = mysql_query($QUERY);
			}
		else
			{
				$NewLimit = ++$Limit;
				$QUERY = "select * from `$TableNames[$TableID]` limit $Limit, $NewLimit";
				$Result = mysql_query($QUERY);
			};
	};
$Next = 0;
while($Raw = mysql_fetch_array($Result))
	{
		$Next++;
	};

if($PageID > 0)
	{
		$Query = "page_id=$OldID&";
		$Exclude[] = "page_id";
		$Exclude[] = "Action";
		$Query .= CompileQuery($Exclude);
		print("<td><a href=main.php?$Query>Previous</a></td>");
	}
else
	{
		print("<td>Previous</td>");
	};	
if($Next > 2)
	{
		$Query = "page_id=$NewID&";
		$Exclude[] = "page_id";
		$Exclude[] = "Action";
		$Query .= CompileQuery($Exclude);
		print("<td><a href=main.php?$Query>Next</a></td>");
	}
else
	{
		print("<td>Next</td>");
	};	
print("<td>Current Page: $NewID</td>");
$NewTotal = $Total;
if($Total != 1)
	{
		$NewTotal = ++$Total;
	};
print("<td>of $NewTotal</td>");
print("</tr>");
print("</table>");

function CompileQuery($Excluded)
	{
		$Keys = array_keys($_GET);
		$KeyCounter = 0;
		$Set = 0;
		foreach($Keys as $Key)
			{
				
				if(!in_array($Key, $Excluded))
					{
						$Query .= $Key."=".$_GET[$Key];
						$Set = 1;
					};
				if($Set == 1 && sizeof($Keys) > $KeyCounter)
					{
						$Query .= "&";
						$Set = 0;
					};
			};
		return $Query;
	};
?>

