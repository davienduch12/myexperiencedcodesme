<?php
error_reporting(E_ALL ^ E_NOTICE);
function Validate($TableID, $FieldID, $Value)
	{
		require("config.php");
		$Key = $TableID."@".$FieldID;
		$Specs = $TableData[$Key];
		$SpecArr = explode("   ",$Specs);
		$Error = "false";
		if ($SpecArr[0] != 0 && $SpecArr[1] != 0)
			{
				if(is_numeric($Value))
					{
						if($Value > $SpecArr[0] || $Value < $SpecArr[1])
							{
								$Error = "true";
							};
					}
				else
					{
						if(strlen(trim($Value)) > $SpecArr[0] || strlen(trim($Value)) < $SpecArr[1])
							{
						
								$Error = "true";
							};
					};
			};
		if(trim($SpecArr['3']) == "False" && trim($Value) == "")
			{
				$Error = "true";
			};
		for($Counter = 0; $Counter < strlen($SpecArr[2]);$Counter++)
			{
				$Char = substr($SpecArr[2],$Counter,1);
				$Temp = explode($Char, $Value);
				if(sizeof($Temp) == 1)
					{
						$Error = "true";
					};
			};
		return $Error;
	};
	
function GetMapping($Table, $Field)
	{
			require("config.php");
				//$Table = $_GET['table_id'];
				$FKeys = explode(";", $FKInfo[$Table]);
				$Counter = 0;
				if($FKeys[0] == "")
					{
						return $Field;
					};
				$FK = array();
				foreach($FKeys as $Key)
					{
						$Temp = explode("@",$Key);
						$FK[$Counter] = $Temp[0];
						$Temp = explode("->",$Temp[1]);
						$Parent[$Counter] = $Temp[0];
						$Mapping[$Counter] = $Temp[1];
						//print("<p>$FK[$Counter] is child of $Parent[$Counter] and mapped to $Mapping[$Counter]</p>");
						if($FK[$Counter] == $Field)
							{
								return $Mapping[$Counter];
							};
						$Counter++;
					};
				return $Field;
	};
	
function GetMappedTables($Table)
	{
		require("config.php");
		$TableID = $_GET['table_id'];
		$Mapped = array();
		$Fields = explode("@", $Tables[$TableID]);
		foreach($Fields as $Field)
			{
				$Temp = GetMapping($TableID, $Field);
				$Tmp = explode(".", $Temp);
				if($Tmp[1] != "")
					{
						if(!in_array($Tmp[0], $Mapped))
							{
								$Mapped[] = $Tmp[0];
							};
					};
			};	
		return $Mapped;
	};	
function FieldExists($TableField)
	{
		$Temp = explode(".", $TableField);
		$Result = mysql_query("select $TableField from $Temp[0] limit 1,1");
		if(!mysql_error())
			{
				return 1;
			}
		else
			{
				return 0;
			};
	};
function GetCorrectKey($Table,$Field)
	{
		$Result = mysql_query("show keys from $Table");
		$cols = array();
		$Match = 0;
		$GoodCol = "";
		while($Raw = mysql_fetch_array($Result))
			{
				$cols[] = $Raw['Column_name'];
			};
		if(sizeof($cols) < 2)
			{
				return $cols[0];
			}
		else
			{
				foreach($cols as $col)
					{
						
						similar_text($Field, $col, $Match);
						if($Match > 75)
							{
								$Match = sizeof($matches);
								$GoodCol = $col;
							};
					};
				return $GoodCol;
			};
	};
		
function GetMappedField($TableID)
	{
		require("config.php");
		$Mapped = array();
		$Fields = explode("@", $Tables[$TableID]);
		foreach($Fields as $Field)
			{
				$Temp = GetMapping($TableID, $Field);
				$Tmp = explode(".", $Temp);
				if($Tmp[1] != "")
					{
						$Mappings[] = "`$TableNames[$TableID]`.`$Field`";
						$CorrField = $Field;
						if(!FieldExists("`$Tmp[0]`.$Field"))
							{
								$CorrField = GetCorrectKey($Tmp[0],$Field);
							};
						$Mappings[] = "`$Tmp[0]`.`$CorrField`";
					};
			};	
		return $Mappings;
	};	
?>
