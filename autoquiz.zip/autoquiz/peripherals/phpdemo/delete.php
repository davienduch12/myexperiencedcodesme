<?php
error_reporting(E_ALL ^ E_NOTICE);
require("config.php");
require("clause.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Delete</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="<?php print($CSS); ?>" />
</head>

<body>
<?php
		require("config.php");
		require("database.php");
		require("validator.php");
		$TableID = $_GET['table_id'];
		$RowID = $_GET['row_id'];
		$Fields = explode("@", $Tables[$TableID]);
		$MappedTables = GetMappedTables($TableID);
		$Mappings = GetMappedField($TableID);
		if($MappedTables[0] != "")
			{
				$qry = "select * from `$TableNames[$TableID]`";
				$Count = 0;
				$Counter = 1;
				foreach($MappedTables as $NewTable)
					{
						$qry .= ",`$NewTable`";
					};
				$qry .= " where (";
				foreach($Mappings as $Mapping)
					{
						if($Counter%2 == 1)
							{
								$qry .= $Mapping."=";
							}
						else
							{
								$qry .= $Mapping;
								if($Counter < sizeof($Mappings))
									{
										$qry .= " and ";
									};
								$Count++;
							};
						$Counter++;
					};
				$qry .= ")";
				if($_GET['desc'] == "TRUE")
					{
						$qry .= " order by `$TableNames[$TableID]`.`$_GET[sortby]` desc";
					}
				elseif($_GET['desc'] == "FALSE")
					{
						$qry .= " order by `$TableNames[$TableID]`.`$_GET[sortby]` asc";
					};

				if(isset($_GET['pri'])&$RowID== -1)

				{
				   $clause = stripslashes($_GET['pri']);
				   $clause = str_replace("%20"," ",$clause);
				   $clause = prepare_clause($clause);
  					 $qry .= " and $clause";

				}
				else
				{
				$qry .= " limit $RowID,1";
				}
			}
		else
			{
				$qry = "select * from `$TableNames[$TableID]`";
				if($_GET['desc'] == "TRUE")
					{
						$qry .= " order by `$TableNames[$TableID]`.`$_GET[sortby]` desc";
					}
				elseif($_GET['desc'] == "FALSE")
					{
						$qry .= " order by `$TableNames[$TableID]`.`$_GET[sortby]` asc";
					};


				 if(isset($_GET['pri'])&$RowID== -1)

				{
				   $clause = stripslashes($_GET['pri']);
				   $clause = str_replace("%20"," ",$clause);
				   $clause = prepare_clause($clause);
  					 $qry .= " where $clause";
				}

				 else
				 {
				$qry .= " limit $RowID,1";
				}

			};
		$Result = mysql_query($qry);
		$Raw = mysql_fetch_array($Result);
		$QUERY = "delete from `$TableNames[$TableID]` where ";
		$FieldCounter = 0;
		foreach($Fields as $Field)
			{
				$Temp = explode("'",$Raw[$Field]);
				$SpaceCHK = explode(" ", $Temp);
				$FloatCheck = explode(".", $Raw[$Field]);
				$Float = false;
				if(is_numeric($Raw[$Field]) && $FloatCheck[1] != "")
					{
						$Float = true;
					};
				if($Raw[$Field] != "" && !$Float && strlen($Raw[$Field]) < 50 && $Temp[1] == "" && $SpaceCHK[1] == "")
					{
						$FieldCounter++;
						if($FieldCounter > 1)
							{
								$QUERY .= " and ";
							};
						$QUERY .= "`$TableNames[$TableID]`.`$Field`="."'".$Raw[$Field]."'";
					};

			};
		mysql_unbuffered_query($QUERY);
		if(mysql_error() == "")
			{
				print("<H3 align=center>Delete successfull</H3>");
				echo '<p align=center><a href="main.php?table_id=';print($TableID);echo '">Home</a></p>';
			}
		else
			{
				print(mysql_error());
			};
?>
</body>
</html>
