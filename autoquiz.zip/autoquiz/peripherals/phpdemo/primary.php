<?php
require_once("database.php");
function get_primary($tbl)
{
global $Fields;

 $q1 = "show columns from `$tbl`";
 $r1 = mysql_query($q1);


  while($ARR = mysql_fetch_array($r1))
  {
    if ($ARR[3]== "PRI"&in_array($ARR[0],$Fields))
   {    	$primary[] = $ARR[0] ;
    }


  }

 return $primary;
}



?>