<?php
print('<html>');
print('<head>');
print('<title>Fuse box test</title>');
print('</head>');
print('<body>');
print('<h3 align="center">Display Name</h3>');
print('<table cellpadding=10 cellspacing=0 align="center" bgcolor="#cccccc" border="3">');
       print('<tr>');
      print('<td>');
       print('First name:</td><td>'.$firstname.'</td>');
       print('<tr>');
       print('<td>');
       print('Last name:</td><td>'.$lastname.'</td>');
       print('</tr>');
     print('</table>');
 print('</body>');
 print('</html>');
?>
