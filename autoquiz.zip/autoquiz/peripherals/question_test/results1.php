<html>
<head>
	<title>score</title>
		<script src="js.php"></script>
<link rel="stylesheet" href="style/layout.css" media="screen" />
</head>
<body>
<div id="container">
<?php include('include/header.php'); ?>
<?php include('include/submenu.php'); ?>
<?php include('include/navmenu.php'); ?>
	<div id="content">
<?php
$score = 0; //initialize score to zero
?>
<h3>Score</h3>
<?php 
$firstname = $_POST['firstname']; 
$question1 = $_POST['question1'];
$question2 = $_POST['question2'];
$question2 = $_POST['question3'];
$question2 = $_POST['question4'];
$question2 = $_POST['question5'];
echo ($firstname); 
?> <p></b></font>
<b>Question 1</b>

<?php
if ($question1 == "answer1.1")
{
echo ("<b>Correct</b>");
$score = $score + 1;
}
else
{
echo ("<b>Incorrect</b>");
}
?></ul>
<p>
<b>Question 2</b>
<?php
if ($question2 == "answer2.3")
{
echo ("<b>Correct</b>");
$score = $score + 1;
}
else
{
echo ("<b>Incorrect</b>");
}
?></ul>
<hr>
<b>Total score:</b>You answered <?php echo ($score); ?> question
<?php
if ($score != 1)
{
echo ("s");
}
?> correctly.
	</div>
</div>
</body>
</html>
