<?php include("includes/setups.php"); ?>
<?php #draw_setups("Web Design Project - registration", "default.css"); ?>
<html>
<head>
<title>Brians Project - registration</title>
<script type="text/javascript">
	function q_and_a(que, ans, anspos, pos)
	{
		this.question = que;
		this.answer = ans;
		this.answerPos = anspos;
		this.myPos = pos;		

		this.draw = draw;
		this.check = check;
	}

	var qList = new Array();
	ansList = new Array("Green", "Red", "Yellow", "Blue");
	qList[0] = new q_and_a("What color is grass?", ansList, 0,  1);

	ansList = new Array("Green", "Red", "Yellow", "Blue");
	qList[1] = new q_and_a("What color is the sky?", ansList, 3, 2);

	ansList = new Array("23", "37", "53", "98");
	qList[2] = new q_and_a("What is 10 + 43?", ansList, 2, 3);

	ansList = new Array("10", "5", "2", "20");
	qList[3] = new q_and_a("What is 100\/20?", ansList, 1, 4);

	ansList = new Array("Cork", "Dublin", "Galway", "Limerick");
	qList[4] = new q_and_a("What is the capital of Ireland?", ansList, 1, 5);

	function draw(div_id)
	{
		var the_string = "<span id=\"q" + this.myPos + "\">";
		the_string += this.myPos + ". " + this.question + "<br />";
		for(var i=0;i<this.answer.length;i++) {
		the_string += "<input type=\"radio\" value=\"" + i + "\" name=\"q" + this.myPos + "R\" onclick=\"moveThis('a" + this.myPos + "', this.value);\" />" + this.answer[i] + "<br />";
		}
		the_string += "<input type=\"hidden\" value=\"-1\" id=\"a" + this.myPos + "\" /></span><br /><br />";

		document.getElementById(div_id).innerHTML += the_string;					
	}

	function check(ans)
	{
		if(this.answerPos == ans)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function checkAll(questions)
	{
		var score = 0;
		for(i=0;i<questions.length;i++)
		{
			the_que_div = "q" + questions[i].myPos;
			the_ans_div = "a" + questions[i].myPos;
			the_answer = document.getElementById(the_ans_div).value;
			temp_score = questions[i].check(the_answer);	
			if(temp_score == 0)
				document.getElementById(the_que_div).style.backgroundColor = "red";
			else
				document.getElementById(the_que_div).style.backgroundColor = "";
			score += temp_score;
		}
		document.getElementById('submenu').innerHTML = "You scored " + score + " out of " + questions.length + ".";
	}

	function drawQSheet(questions, div_id)
	{
		document.getElementById(div_id).innerHTML = "<u><h3>Questions</h3></u>";
		for(i=0;i<questions.length;i++)
		{
			questions[i].draw(div_id);
		}
		document.getElementById(div_id).innerHTML += "<br /><button onclick=\"eval('checkAll(qList);');\">Check your answers</button><br /><br />";
	}

	function moveThis(tagId, val) {
		document.getElementById(tagId).value = val;
	}
</script>
<link rel="stylesheet" href="style/layout.css" media="screen" />
</head>
<body>
<div id="container">
<?php #include('includes/header.php'); ?>
<?php #include('includes/submenu.php'); ?>
<?php #include('includes/menu.php'); ?>
<?php #draw_menu(3); ?>
<div id="content">
<?php
if(isset($_POST["quiz_id"])) {
$qid = $_POST["quiz_id"];
$id = 1;

$con = mysql_connect("localhost", "root", "") or die("<p>Unable to connect to the DBMS : Error code #".mysql_error()."<br /></p>");
mysql_select_db("quizes", $con);

$strQ = "SELECT title FROM quizes WHERE autokey = ".$qid.";";
$result = mysql_query($strQ) or die ("<p>Error accessing database : Error code #".mysql_error()."<br /></p>");

$row = mysql_fetch_array($result);
echo "<h2>".$row["title"]."</h2><p></p>";
echo "<p><div style=\"width:65%;text-align:right;top:-20px;\"><a href=\"take_a_quiz.php\">Take another quiz</a></div><form action=\"score_test.php\" method=\"POST\">";
echo "<input type=\"hidden\" id=\"quiz_id_num\" name=\"quiz_id_num\" value=\"".$qid."\" />";

$strQ = "SELECT * FROM questions WHERE quiz_id = ".$qid.";";
$result = mysql_query($strQ) or die ("<p>Error accessing database : Error code #".mysql_error()."<br /></p>");

while($row = mysql_fetch_array($result)) {
echo "<ul class=\"quizList\"><u>".$id.". ".$row["q_text"]."</u>";
$strA = "SELECT * FROM answers WHERE question_id = ".$row["autokey"].";";
$resultA = mysql_query($strA) or die ("<p>Error accessing database : Error code #".mysql_error()."<br /></p>");
while($rowA = mysql_fetch_array($resultA)) {
echo "<li><input type=\"radio\" name=\"q".$row["autokey"]."\" id=\"q".$row["autokey"]."\" value=\"".$rowA["autokey"]."\" />".$rowA["a_text"]."</li>";
}
echo "</ul>";
$id++;
}

echo "<hr /><input type=\"submit\" value=\"Submit\" /></form></p>";
mysql_close($con);
}
else {
?>
<h2>Take A Quiz</h2>
<p></p>
<form action="take_a_quiz.php" id="quizFrm" name="quizFrm" method="POST">
<table>
<tr>
<td>
Please select a quiz to take from the list below then press submit:
</td>
</tr>
<tr>
<td>
<!-- this code can be updated to take advantage of AJAX -->
<select id="quiz_id" name="quiz_id">
<?php
$con = mysql_connect("localhost", "root", "") or die("<p>Unable to connect to the DBMS : Error code #".mysql_error()."<br /></p>");
mysql_select_db("quizes", $con);

$strQ = "SELECT * FROM quizes ORDER BY title;";
$result = mysql_query($strQ) or die ("<p>Error accessing database : Error code #".mysql_error()."<br /></p>");

while($row = mysql_fetch_array($result)) {
echo "<option value=\"".$row["autokey"]."\">".$row["title"]."</option>";
}
mysql_close($con);
?>
</select>
</td>
</tr>
<tr>
<td>
<input type="submit" value="Submit" />
</td>
</tr>
</table>
</form>
<?php
}
?>
</div>
</div>
</body>
</html>
