<html>
<head>
	<title> take quiz</title>
		<script src="js.php"></script>
<link rel="stylesheet" href="style/layout.css" media="screen" />
</head>
<body>
<div id="container">
<?php include('include/header.php'); ?>
<?php include('include/submenu.php'); ?>
<?php include('include/navmenu.php'); ?>
	<div id="content">
<form action=results1.php method="POST"> 
<HR>
<UL><FONT COLOR="#CCCCCC"> When finished, click the "submit" button.</FONT></UL>
<UL>
</ul></ul>
<li>First name:<INPUT TYPE="TEXT" NAME="firstname" size="35"></li><br>
<UL>
1. question1?
<UL>
<INPUT TYPE="RADIO" NAME="question1" VALUE="answer1.1">opt1<BR>
<INPUT TYPE="RADIO" NAME="question1" VALUE="answer1.2">opt2<BR>
<INPUT TYPE="RADIO" NAME="question1" VALUE="answer1.3">opt3<BR>
</UL></UL>
2. question2?
<UL>
<INPUT TYPE="RADIO" NAME="question2" VALUE="answer2.1">opt1<BR>
<INPUT TYPE="RADIO" NAME="question2" VALUE="answer2.2">opt2<BR>
<INPUT TYPE="RADIO" NAME="question2" VALUE="answer2.3">opt3<BR>
</UL></UL>
<INPUT TYPE="SUBMIT" VALUE="Submit">
<INPUT TYPE="RESET" VALUE="Reset">
</ul></ul>
</FORM>
</div>
</div>
</body>
</html>
