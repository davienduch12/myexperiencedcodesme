<?php
header('Location: ./admin/login.php');
?>
<html>
<head>
	<title></title>
</head>
<body>
</body>
</html>