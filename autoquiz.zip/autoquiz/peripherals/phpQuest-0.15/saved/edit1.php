<html>
<head>
	<title>Delete, View, Edit - Quiz/Test</title>
</head>
<body>

<?php
$hdl = opendir('./'); //Dir name
while ($dirEntry = readdir($hdl)) {
    if (substr($dirEntry, 0, 1) != '.' && is_dir($dirEntry)) {
        $Dirs[] = $dirEntry;
    } 
} 
if ($Dirs == "") {
    die("<center>Sorry not tests or quizes made yet.</center><br>\n");
} else {
	echo "Here is a list of current directories in you <i>saved</i> directory. You can delete, view and edit you test(s) and or quiz(s)<br>\n";
	echo "<b>Note: </b>When you <i>delete</i> a directory its gone, you can't get it back.\n<br><br>\n";
	echo "<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\">\n";
	echo "<tr>\n";
    echo "	<td width=\"51\"><strong>Detete</strong></td>\n";
    echo "	<td width=\"40\"><strong>View</strong></td>\n";
    echo "	<td width=\"35\"><strong>Edit</strong></td>\n";
    echo "	<td width=\"86\"><strong>Date Made</strong></td>\n";
    echo "	<td width=\"78\"><strong>Owner</strong></td>\n";
	echo "	<td width=\"69\"><strong>Size</strong></td>\n";
    echo "	<td width=\"682\"><strong>Name</strong></td>\n";
    echo "</tr>\n";
    natsort($Dirs);		// Sort the dir array
    closedir($hdl);		// Close the dir
    foreach($Dirs as $Dir) {
        echo "<form action=\"edit2.php\" method=\"post\" name=\"Quest\" id=\"Quest\">\n";
        echo "<tr>";
        echo "	<td width=\"51\"><div align=\"center\">\n";
        echo "		<input name=\"Action\" type=\"submit\" id=\"Action\" value=\"Delete\">\n";
        echo "		</div></td>\n";
        echo "	<td width=\"40\"><div align=\"center\">\n";
        echo "		<input name=\"Action\" type=\"submit\" id=\"Action\" value=\"View\">\n";
        echo "		</div></td>\n";
        echo "	<td width=\"35\"><div align=\"center\">\n";
        echo "		<input name=\"Action\" type=\"submit\" id=\"Action\" value=\"Edit\" disabled=\"disabled\">\n";
        echo "		</div></td>\n";
        echo "	<td width=\"86\">" . date("m/d/Y", filemtime($Dir)) . "</td>\n";
        echo "	<td width=\"78\">" . fileowner($Dir) . "</td>\n"; 
        // This stuff well calcualte the sizr of each dir.
        $FileDir = opendir($Dir);
        while ($File = readdir($FileDir)) {
            $Files[] = $File;
        } // while
        closedir($FileDir);
        foreach ($Files as $File) {
            $FileSize = $FileSize + filesize("./$Dir/$File");
        } 
        echo "	<td>" . round($FileSize / 1024) . "KB</td>"; //Dividing by 1024 will make the bytes read KBs
        $FileSize = "";
        $File = "";
        $Files = "";
        echo "	<td> <input name=\"DirName\" type=\"hidden\" id=\"DirName\" value=\"$Dir\">$Dir</td>\n";
        echo "	</tr>";
        echo "</form>";
    }
	echo "</table>\n"; 
} 
?>
	<? include '../footer.php' ?>
</body>
</html>