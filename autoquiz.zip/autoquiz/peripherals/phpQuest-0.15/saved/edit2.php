<?php 
// This has to be done in before it all...
if ($Action == "View") {
    header('Location: ./' . $DirName . '/');
} 
?>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
// Debug stuff...
// echo "Debug<br>\n";
// echo "<textarea name=\"debug\" cols=\"40\" rows=\"20\">\n";
// print_r($HTTP_POST_VARS);
// echo "</textarea>\n<br>\n<br>\n";
// This is attempt to delete all the files in a dir and than
// delete the dir.
if ($Action == "Delete") { // Check for the action
    if (is_dir($DirName)) { // Check if its a dir
        $FileDir = opendir("$DirName"); //Open the dir
    } while ($File = readdir($FileDir)) {
        if ($File != "." && $File != "..") {
            $Files[] = $File; //Load up the array with all the valid files
        }
    } // while
    foreach ($Files as $File) {
        // $RootPath = "/home/max/public_html/dir/";		//Root var of the app
        if (unlink('./' . $DirName . '/' . $File)) { // Delete the file
            echo "File <b>$File</b> has been deleted<br>\n";
        } else {
            echo "<b>Error: </b> $File has not deleted. Could not delete ./$DirName/$File<br>\n";
        } 
    } 
    if (rmdir('./' . $DirName)) { // Delete the dir
        echo "Directory <b>$DirName</b> has been deleted<br>\n";
    } else {
        echo "<b>Error: </b> $DirName has not deleted.<br>\n";
    } 
    closedir($FileDir); //Close it! 
    // Now for the view action.
}elseif ($Action=="Edit"){		//Edit module...
	require './' . $DirName . '/include.php';		//Load up the file...
	echo "Edit go!<br>\n";
	echo "	<form name=\"QuestEdit\" method=\"post\" action=\"$PHP_SELF?Action=Edit2\">\n";
	echo "  <table width=\"400\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
	echo "    <tr> \n";
	echo "      <td width=\"100\"><strong>Title:</strong></td>\n";
	echo "      <td width=\"300\"><input name=\"Title\" type=\"text\" value=\"$Title\" size=\"30\"></td>\n";
	echo "    </tr>\n";
	echo "    <tr> \n";
	echo "      <td><strong>Description:</strong></td>\n";
	echo "      <td><input name=\"Description\" type=\"text\" value=\"$Description\" size=\"30\"></td>\n";
	echo "    </tr>\n";
	if ($Type=="Test") {		//We only want Output name option displyed if it's a test
	    echo "    <tr> \n";
		echo "      <td><strong>Output Name:</strong></td>\n";
		echo "      <td><input name=\"Name\" type=\"text\" value=\"$Name\" size=\"30\"></td>\n";
		echo "    </tr>\n";
	}
	echo "    <tr> \n";
	echo "      <td><strong>Type:</strong></td>\n";
	echo "      <td>$Type</td>\n";
	echo "    </tr>\n";
	echo "      <td><strong>Directory:</strong></td>\n";
	echo "      <td>$DirName<br></td>\n";
	echo "    </tr>\n";
	echo "    <tr> \n";
	echo "      <td colspan=\"2\">";
	echo "<br>";
	//This is the edit data..
	$QuestionArray = 0;
	// This will generate the questions in forms for editing
	foreach($Quiz as $Question) {
    	$QuestionArray++;
    	echo "Question $QuestionArray: <input name=\"Question\" type=\"text\" value=\"" . $Quiz[$QuestionArray]['Question'] . "\" size=\"30\">\n<br>\n";
   		foreach($Quiz[$QuestionArray]['Options'] as $Option) {
			$Count++;		//This just a temp variable to have numbered answers.
        	#echo "<blockquote>\n";
			echo "	Option $Count: \n";
			echo "	<input type=\"text\" name=\"Q$QuestionArray\" value=\"$Option\">\n<br>\n";
			#echo "</blockquote>\n";
    	} 
		//Answer option part..
		echo "	Answer $QuestionArray\n";
		echo "	<select name=\"Ans" . $QuestionArray . "\"\n";
		while($Count >= $i){	//This will be the answer option picker loop
			echo "		<option value=\"" . $i . "\">Option: " . $i . "</option>\n";
			$i++;		//This $i var makes it so the options count up, if I used just $Count the options would count down 3,2,1...
		} // while
		echo "	</select>\n";
        echo "	<br>\n";
		$i = "";
		$Count = "";			//Clear it!
   	 	echo "<br>\n";
	} 
	echo "	    </td>\n";
	echo "    </tr>\n";
	echo "    <tr> \n";
	echo "      <td colspan=\"2\"><div align=\"center\">\n";
	echo "          <input type=\"submit\" name=\"Submit\" value=\"Submit\">\n";
	echo "        </div></td>\n";
	echo "    </tr>\n";
	echo "  </table>\n";
	echo "</form>\n";
}elseif ($Action=="Edit2"){
	// Debug stuff...
	echo "Debug<br>\n";
	echo "<textarea name=\"debug\" cols=\"40\" rows=\"20\">\n";
	print_r($HTTP_POST_VARS);
	echo "</textarea>\n<br>\n<br>\n";}
?>
<? include '../footer.php' ?>
</body>
</html>