<?php
//This is the file with all the Quiz options, and answers
$Title = "Geek Quiz!";
$Description = "This is a test quiz, This is the first quiz my \"Quest\" system has even done";
$Name = "Geek";
$Type = "Test";
$HTMLOut = "Yes";
$QuizID="1234abcd";
$Store="Yes";
$Quiz = array(
	"1" => array("Question" => "Whats the <i>bandwidth</i> on DDR-333, PC2700?",
        "Options" => array("12KBs", "3.7GBs", "2.7GBs", "333MBs"),
        "Answer" => "2.7GBs",
        ),
    "2" => array("Question" => "What does <i>GNU</i> stand for?",
        "Options" => array("GNU's not Unix!", "Gay Nergo Universcity", "Geeky Nerds Unight!"),
        "Answer" => "GNU's not Unix!",
        ),
    "3" => array("Question" => "Is this a kick ass php <i>quiz</i>?",
        "Options" => array("Ya d00d!", "No! j00 sucks!", "whats PHP?", "I saw a kitty"),
        "Answer" => "Ya d00d!",
        ),
	"4" => array("Question" => "Do you consider your mates <i>IRC</i> real friends?",
        "Options" => array("No! Unless we have fleshmet", "Yes!", "Someone tell me what this kid is talking about!"),
        "Answer" => "No! Unless we have fleshmet",
        ),
	"5" => array("Question" => "j0 5p34k <i>l337</i>?",
        "Options" => array("y3ah d00d!", "I'm not sure how to respond...", "What are you speaking Greace?", "I'm Hip! I'm with it!"),
        "Answer" => "y3ah d00d!",
        ),
	"6" => array("Question" => "Which of these are <i>*nix</i> commands?",
        "Options" => array("dir /p", "DMX", "What is a nix?", "rm -fr /", "deltree C:"),
        "Answer" => "rm -fr /",
        ),
	"7" => array("Question" => "In the <i>Matrix 2</i> how did Trinity exploit the nix box??",
        "Options" => array("Err! WTF is a nix?", "With an exploiter, duh!", "SSHNuke"),
        "Answer" => "SSHNuke",
        ),
	"8" => array("Question" => "Would you even give someone <i>shell</i> access on your system?",
        "Options" => array("No!", "Yes!", "The beach is nice"),
        "Answer" => "No!",
		)
    );
$Rank = array(
	"1" => "Level 1",
	"2" => "Level 2",
	"3" => "Level 3",
	"4" => "Level 4"
);


?>