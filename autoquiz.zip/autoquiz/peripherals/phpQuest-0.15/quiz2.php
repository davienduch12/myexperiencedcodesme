<?php 
// Vars! //
require './include.php';
$Score = 0;
// End of Vars! //
/**
 * ***********COOKIE STUFF!**************
 * What this will do is first check to see
 * if there is a cookie that has data in
 * it. Next if there is no cookie we then
 * calc the score and enter that data into
 * the cookie.
 */
$i = unserialize($_COOKIE['Quest']); //Unserialize the data in the cookie (if there is one) and put the array in the var "$i"
if ($i[TotalScore]) { // If there is a data from the cooke do this...
    $TotalScore = $i[TotalScore]; //Put data from the score in the cookie
    $CookieData = serialize(array ("QuizID" => $QuizID, "Taken" => "Yes", "TotalScore" => $TotalScore)); //Load up the data!
    setcookie("Quest", $CookieData, time() + 60 * 60 * 24 * 30); //Bake the cookie!
} else {
    // This will clac the score..
    foreach($Quiz as $Question) {
        // This is a quite verison of the answer checker as show above...
        $QuestionArray++;
        $Var = "Q" . $QuestionArray; 
        // This var is for the ammount of questions this will be used to calc the grade
        $QuestionAmt = $QuestionAmt + 1;
        if (stripslashes($$Var) == stripslashes($Quiz[$QuestionArray]['Answer'])) {
            $Score = $Score + 1;
        } 
    } 
    $TotalScore = round($Score / $QuestionAmt * 100); // Calc the score and round it
    $CookieData = serialize(array ("QuizID" => $QuizID, "Taken" => "Yes", "TotalScore" => $TotalScore)); //Cookie data
    setcookie("Quest", $CookieData, time() + 60 * 60 * 24 * 30); //Bake it!
} 
// Clear dem vars!
$Question = "";
$Var = "";
$QuestionArray = "";
$QuestionAmt = "";
/*
**********END OF COOKIE STUFF!***********
*/

/**
 * ******GET THE AVG SCORE FUNCTION******
 */
function AvgScore($Score, $Type, $Rank){
	$ScoreFile = "./score.dat";
	$Number = $Score;
	if (is_writeable($ScoreFile)) {		//Fist make sure the file is writable.
    	if (!$fp=fopen($ScoreFile, "a+", filesize($ScoreFile))) {		//Make sure you can open the file.
   			exit("<b>Error: </b>Could not open $File");
		}else{
			$Number = $Number . "\n";	
			fwrite($fp, $Number);	//Wirte the score to the next line.
			fclose($fp);	//close the file!
		}
	$Numbers = file($ScoreFile);		//Load the whole file into an array called $Numbers
	$NumberSum = array_sum($Numbers);
	$NumberCount = count($Numbers);
	$NumberAvg = round($NumberSum/$NumberCount);	//Devide the per-added numbers and round them...
	
	if ($NumberAvg=="" or $NumberAvg<=0) {	//Make sure its okay to divide
	    exit("Your are the first perosn to take this $Type<br>\n");
	}elseif ($Type == "Test") {		//This is for the average score output for tests
	    echo "Out of $NumberCount people the average score was <b>$NumberAvg%</b><br>\n";
	}elseif ($Type == "Quiz"){		//Thisis for the average score output for a quiz
		if ($NumberAvg <= 25 and $NumberAvg >= 0) {
            echo "<br>Out of $NumberCount people the average level was <b>" . $Rank[1] . "</b><br>\n";
            $RankTmp = 1; //This is tmp var that will be used when and if there is a html output.
        } elseif ($NumberAvg <= 50 and $NumberAvg >= 26) {
            echo "<br>Out of $NumberCount people the average level was <b>" . $Rank[2] . "</b><br>\n";
            $RankTmp = 2;
        } elseif ($NumberAvg <= 75 and $NumberAvg >= 51) {
            echo "<br>Out of $NumberCount people the average level was <b>" . $Rank[3] . "</b><br>\n";
            $RankTmp = 3;
        } elseif ($NumberAvg <= 100 and $NumberAvg >= 76) {
            echo "<br>Out of $NumberCount people the average level was <b>" . $Rank[4] . "</b><br>\n";
            $RankTmp = 4;
        }
	}
}
/**
 * ******END OF THE AVG SCORE FUNCTION******
 */
}
?>

<html>
<head>
	<title><?php echo "$Title $Type - Page 2";

?></title>
</head>
<body>
<?php
$i = unserialize($_COOKIE['Quest']);
if ($i[QuizID] == $QuizID and $i[Taken] == "Yes") {
    echo "<b>Error: </b>Sorry you can only take the $Type one time.<br>\n";
    if ($Type == "Test") {
        echo "Remember you got a <i>$TotalScore%</i> on your last test.<br>\n";
    } 
} else { // They have passed all the cookie shit now run like the wind!
    if ($Type == "Test") {
        foreach($Quiz as $Question) {
            // Besauce this is a test it's output will be very verbosy (har har)
            $QuestionArray++;
            echo "Question " . $QuestionArray . ": " . $Quiz[$QuestionArray]['Question'] . "<br>\n";
            /* $Var is to combine $Q* with $QuestionArray to yeild somthing
				* like $Q2 and then it is echo in the next line... This is done
				* becasue this var but be dynamicly changed 
				*/
            $Var = "Q" . $QuestionArray;
            // This var is for the ammount of questions this will be used to calc the grade
            $QuestionAmt = $QuestionAmt + 1;
            echo "You <i>answered</i> \"" . $$Var . "\"<br>\n";
            echo "The <i>correct</i> answer is \"" . $Quiz[$QuestionArray]['Answer'] . "\"\n<br>\n";
            if (stripslashes($$Var) == stripslashes($Quiz[$QuestionArray]['Answer'])) {
                echo "You are <b>correct!</b>\n<br>\n";
                $Score = $Score + 1;
            } elseif ($$Var != $Quiz[$QuestionArray]['Answer']) {
                echo "Your are <b>wrong!</b>\n<br>\n";
            } 
            echo "<br>\n";
        } 
        // $TotalScore = round($Score/$QuestionAmt*100);		// this is not needed b/c the cookie thing does it!
        if ($Name) { // Check for a name...
            echo "You are <b>" . $TotalScore . "</b>% " . $Name . "\n<br><br>\n";
        } else { // if no name then output generic style
            echo "Score: <b>" . $TotalScore . "</b>%\n<br>\n";
        } 
		if ($Store=="Yes") {		//Check if they want to store the scores
		    @AvgScore("$TotalScore", "Test");	//Use the @ becasue there should be 3 values but the third one is not needed for the test
		}
        // Now for the HTML text area in the test output.
        if ($HTMLOut == "Yes") {
            echo "<br>\nCopy and paste this text into your own web site or blog.<br>\n";
            echo "<textarea name=\"HTMLOut\" cols=\"40\" rows=\"5\">\n";
            echo "<center>I got a $TotalScore% on the $Title test!<br>\n";
            echo "Click <a href=\"http://" . $HTTP_HOST . dirname($_SERVER["REQUEST_URI"]) . "/\">here!</a> to take it</center>\n";
            echo "</textarea>\n";
        } //End on the HTML out for test
    } elseif ($Type == "Quiz") {
        if ($TotalScore <= 25 and $TotalScore >= 0) {
            echo "<b>" . $Rank[1] . "</b>";
            $RankTmp = 1; //This is tmp var that will be used when and if there is a html output.
        } elseif ($TotalScore <= 50 and $TotalScore >= 26) {
            echo "<b>" . $Rank[2] . "</b>";
            $RankTmp = 2;
        } elseif ($TotalScore <= 75 and $TotalScore >= 51) {
            echo "<b>" . $Rank[3] . "</b>";
            $RankTmp = 3;
        } elseif ($TotalScore <= 100 and $TotalScore >= 76) {
            echo "<b>" . $Rank[4] . "</b>";
            $RankTmp = 4;
        } 
		if ($Store=="Yes") {		//Check if they want to store the scores
		    AvgScore("$TotalScore", "Quiz", $Rank);
		}
        // Now for the HTML text area in the quiz output.
        if ($HTMLOut == "Yes") {
            echo "\n<br>\nCopy and paste this text into your own web site or blog.<br>\n";
            echo "<textarea name=\"HTMLOut\" cols=\"40\" rows=\"5\">\n";
            echo "<center>I am a $Rank[$RankTmp]<br>\n";
            echo "Click to take the <a href=\"http://" . $HTTP_HOST . dirname($_SERVER["REQUEST_URI"]) . "/\">$Title quiz!</a></center>\n";
            echo "</textarea>\n";
        } //End on the HTML out for quiz
    } else {
        echo "<b>Error: </b>Type mismatch\n<br>\n";
    } 
} 

?>
	<?php include 'footer.php'?>
</body>
</html>