===============================================
              phpQuest 0.15
===============================================
Date:		02-24-2004
Site:		http://www.DynamicDeeds.com
Arthur:		Max Kaplan
Contact:	maxk@optonline.net

TOC:
  1. Intro
  2. Features
  3. Installation
  4. Features to Come...
  5. Bugs
  6. FAQ
  7. Thanks...


1. INTRO and NEWS:
------------------
    phpQuest is a Quiz and Test script programed in
php. Thus it is a "Quest." This script is still in
dev but I will cotinue with it later.

    New! Now you can make your quiz/tests show the average
of all the other people that have taken the test/quiz so far.

	Coming soon, I'm working on an edit interface to non-tech
people don't have to edit their include.php files to change things.
As of right now this option is disabled.


2. FEATURES (CURRENT):
---------------------
  +Make a Test
    -This is great if you would like to test the
     users on your site.
    -This outputs a numeric number value, and even
     a title if you wish. (ex "Your are 70% geekx0rz")

  +Make a Quiz
    +Rank System
      -Lets the quiz maker have 4 custiom ranks for
       when the user gets 0-25%, 26-50%, etc...
      -Also a way for the user to uplaod pictures
       that repersent each rank
    -Quiz is simalar to somthing you might see in
     a magazine or on a blog.
    -Quiz outputs a _non_ numeric value rather it
     outputs somthing like "Your a geekx0r!"
	 
  +Generic
  	-Delete a Quiz/Test
	-phpQuest dosent need any other files to run you
	 quizes and tests so zip up your dir and send it out!

  +HTML Output
    -After the user takes your quiz there could be a
     feild for them to copy the score or rank they got
     into their own website. (This is great for bloggers) 
	 
  +Over all user rating, if its a "test" then the test
   maker will have the option of showing users after taking
   the test what the average score was. (Might use SQL later on)
   
  +Customization
    -You decide how many quesions and options you want.

  +Generation
    +Save
      -User can save their generated quiz to the
       local web server.

  +Cookies! This will stop people from the same computer
   or IP address from taking the quiz/test over and over.
   Well all know it will not be the most secure way but it
   will be okay.

  +No god damm SQL! (Yet!)


3. INSTALLATION:
----------------
    Edit your 'confif.php' file. Uplaod all your files to a webserver.
Make sure in "quiz" there is a dir called "saved" and chmod it to "0755"

   When a quiz is saved it will go to ./saved/<quiz name>

   Take a look at the _bugs_!

4. VAPOR FEATURES:
------------------
Here are some features that are to come don't worry! If
you have an idea for a feature, drop me a line.

  +Add a way to edit the quiz/tests that you make by telling
   the script where the quiz/test is and then edit the include.php
   
  +A randomize mode so the order of questions are different each time.

  +More customizalbe look and beter layout for the whole
   quest experance. 

5. BUGS:
--------
  The admin part of this program is very week. I'm sure its easy to break
I will make it more secure and implament cookies in the versions to come.

  My poor spelling and grammer throguh out all the docs har har...

6. FAQ:
-------
   I have not real user input yet so... e-mail me.

7. THANKS:
----------
   All the work:		Max Kaplan
   Special Thanks:		r3n, Michael Nutt, Shai-Tan, and the #php chan on efnet!
   Testers:				Jon, Ryan, Ashley, Max (Not me)