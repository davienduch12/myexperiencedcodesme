<html>
<head>
	<title>Make a Quiz/Test - Setp 3</title>
</head>
<body>
  <?php
/****************************************
 ************ERROR CHECKING!*************
 * This will check for many erreros like
 * feilds that are left blank and such.*
 ****************************************/
echo "Checking for errors...<br>";
// This will look for errors in the ranks...
if ($Type == "Quiz") { // This is make sure there is a rank (there is only a rank if its a quiz)
    while ($i <= 3) { // This will load up the ranks into the include.php
        $i++;
        $RankVar = "RankLvl" . $i; //This is a temp var
        if ($HTTP_POST_VARS[$RankVar] == "") { // This is b/c the change in the last element in the array
            echo "<b>Error: </b> Rank #$i is blank.<br>\n";
            $Error = 1;
        } 
    } // while  
    // Clear all temp vars for later use
    $i = "";
    $k = "";
} // End of rank checker.  
// Now to check the rest (questions, options, answers)
$i = $Number;
while ($i >= 1) {
    $i--;
    $QuestNumber++; 
    // This is to make a var that can be used to call the right value in $HTTP_POST_VAR array
    $QuestVar = "Quest" . $QuestNumber;
    if ($HTTP_POST_VARS[$QuestVar] == "") {
        echo "<b>Error: </b> You left question #$QuestNumber blank.<br>\n";
        $Error = 1;
    } 
    // Now for the options
    $g = $Options;
    while ($g >= 1) {
        $g--;
        $OptNumber++; 
        // This is same as for $QuestVar but for the options
        $OptVar = "Opt" . $QuestNumber . "_" . $OptNumber;
        if ($HTTP_POST_VARS[$OptVar] == "") {
            echo "<b>Error: </b> For question #$QuestNumber, option #$OptNumber was left blank.<br>\n";
            $Error = 1;
        } 
    } // while    
    // This will clear all the temp vars...
    $g = "";
    $OptNumber = ""; 
    // Now for the amswers...
    $AnsVar = "Ans" . $QuestNumber; //This sets up the call for HTTP vars...
    $AnsTmp = $HTTP_POST_VARS[$AnsVar]; //This is the call...
    $Ans = "Opt" . $QuestNumber . "_" . $AnsTmp; // Now we make the answer = to the options test...
    if ($HTTP_POST_VARS[$AnsVar] == "") {
        echo "<b>Error: </b> Answer for question #$QuestNumber in blank.<br>\n";
        $Error = 1;
    } 
} // while

// Need to rest the vars for later use in the real program...
$QuestNumber = "";
$AnsTmp = "";
$AnsVar = "";
$Ans = "";
// Option check done!

// This will warn the user if there are html vars in his data
foreach ($HTTP_POST_VARS as $PostVar1) {
    $PostVar2 = htmlspecialchars($PostVar1);
    if ($PostVar1 != $PostVar2) {
        $g++; //This will make it so it only shows the error one time...
    } 
} 
if ($g >= 1) {
    echo "<b>Warning: </b>You have entered data that has html tags in it. All html will be filtered.<br>\n";
} 
$g = "";
// end of check

if ($Title == "" or $Description == "") {
    if ($Title == "") {
        echo "<b>Error: </b> You <i>must</i> have a title.<br>\n";
        $Error = 1;
    } 
    if ($Description == "") {
        echo "<b>Error: </b> You <i>must</i> have a description.<br>\n";
        $Error = 1;
    } 

    /*****************************************
     ************END OF ERROR CHECK***********
     *****************************************/

    /***************************************
     *************MAIN PROGRAM**************
     * Here is the rest of the script..
     ***************************************/
} elseif ($Error >= 1) {
    echo "<b>Error: </b> Sorry the data you inputed did not pass our error system. Please go back and fix the above errors.\n<br><br>\n";
} elseif ($Error <= 0) { // Go proggy go!
    // Filter out any html code the user might had put in.
    $Title = htmlspecialchars($Title);
    $Description = htmlspecialchars($Description); 
	
    // Debug stuff...
    // echo "Debug<br>\n";
    // echo "<textarea name=\"debug\" cols=\"40\" rows=\"20\">\n";
    // print_r($HTTP_POST_VARS);
    // echo "</textarea>\n<br>\n<br>\n"; 
	
    // This is saveing stuff
	
    $DirStat = mkdir("./saved/$DirName", 0777); //This should reture a 1 if the dir was made the "@" stops php from outputting a gay error msg. 
    // This sees if the dir was made.
    if ($DirStat == 0) {
        echo "<b>Error: </b>$DirName was not made, make sure you have the right permmissons or you are not tring to make 2 of the same directories.<br>\n";
    } elseif ($DirStat == 1) { // If it passes here then we can go on to make the files etc...
        echo "$DirName was succesfulyt made!<br>\n"; 
        // Include.php go!
        $FileInc = fopen("./saved/$DirName/include.php", "w+"); 
        // this will write to include...
        fwrite($FileInc, "<?php\n");
        fwrite($FileInc, "\$Title = \"$Title\";\n");
        fwrite($FileInc, "\$Description = \"$Description\";\n");
        fwrite($FileInc, "\$Type = \"$Type\";\n");
        fwrite($FileInc, "\$HTMLOut = \"$HTMLOut\";\n");
        fwrite($FileInc, "\$Store = \"$Store\";\n");
        $QuizID = crypt($Title); //Cryot is up be-othc!
        fwrite($FileInc, "\$QuizID = \"$QuizID\";\n"); //This will be used for cookies, each quiz needs it own id.
        if ($Name) { // If there is a custom name do this!
            fwrite($FileInc, "\$Name = \"$Name\";\n");
        } else { // If its blank
            fwrite($FileInc, "\$Name = \"\";\n");
        } 
        // Now for the rank array
        if ($Type == "Quiz") { // Check if its a quiz and thus there is a rank...
            fwrite($FileInc, "\$Rank = array(\n");
            while ($i <= 3) { // This will load up the ranks into the include.php
                $i++;
                $RankVar = "RankLvl" . $i; //This is a temp var
                $HTTP_POST_VARS[$RankVar] = htmlspecialchars($HTTP_POST_VARS[$RankVar]); //html filter for the quiz ranks
                if ($i == 4) { // This is b/c the change in the last element in the array
                    fwrite($FileInc, "	\"$i\" => \"$HTTP_POST_VARS[$RankVar]\"\n");
                } else {
                    fwrite($FileInc, "	\"$i\" => \"$HTTP_POST_VARS[$RankVar]\",\n");
                } 
            } // while
            fwrite($FileInc, ");\n"); 
            // Clear all temp vars for later use
            $i = "";
            $k = "";
        } //end    
        // Now for the question array...
        fwrite($FileInc, "\$Quiz = array( \n"); 
        // Now for the arrays....
        $i = $Number;
        while ($i >= 1) {
            $i--;
            $QuestNumber++; 
            // This is to make a var that can be used to call the right value in $HTTP_POST_VAR array
            $QuestVar = "Quest" . $QuestNumber;
            $HTTP_POST_VARS[$QuestVar] = htmlspecialchars($HTTP_POST_VARS[$QuestVar]); //HTML char filter for the questions
            fwrite($FileInc, "	\"$QuestNumber\" => array(\"Question\" => \"$HTTP_POST_VARS[$QuestVar]\",\n"); 
            // Now for the options
            fwrite($FileInc, "		\"Options\" => array(");
            $g = $Options;
            while ($g >= 1) {
                $g--;
                $OptNumber++; 
                // This is same as for $QuestVar but for the options
                $OptVar = "Opt" . $QuestNumber . "_" . $OptNumber;
                $HTTP_POST_VARS[$OptVar] = htmlspecialchars($HTTP_POST_VARS[$OptVar]); //html filter for the options  
                // Thisis becasue there is no "," at the end of the array.
                if ($Options == $OptNumber) {
                    fwrite($FileInc, "\"$HTTP_POST_VARS[$OptVar]\"),\n");
                } else {
                    fwrite($FileInc, "\"$HTTP_POST_VARS[$OptVar]\",");
                } 
            } // while    
            // This will clear all the temp vars...
            $g = "";
            $OptNumber = ""; 
            // Now for the amswers...
            $AnsVar = "Ans" . $QuestNumber; //This sets up the call for HTTP vars...
            $AnsTmp = $HTTP_POST_VARS[$AnsVar]; //This is the call...
            $Ans = "Opt" . $QuestNumber . "_" . $AnsTmp; // Now we make the answer = to the options test...
            $HTTP_POST_VARS[$Ans] = htmlspecialchars($HTTP_POST_VARS[$Ans]); //html filter for the answers
            fwrite($FileInc, "		\"Answer\" => \"$HTTP_POST_VARS[$Ans]\",\n"); 
            // THis is for the chagne in syntax for the last object in the array
            if ($Number == $QuestNumber) {
                fwrite($FileInc, "		)\n");
            } else {
                fwrite($FileInc, "		),\n");
            } 
        } // while
        fwrite($FileInc, ");\n"); //end of array
        fwrite($FileInc, "?>");
        echo "include.php was <b>made</b>.<br>\n";
        fclose($FileInc); //include.php made and done    
        // index.php (aka step 1) go!
        /* Basicly how this works is it copies the data from a file
				*  into a string and then writes that string to a different
				*  file in a differnt place.*/
        $FileStep1 = fopen("./saved/$DirName/index.php", "w+"); //File tah twill be written to...
        $FileName = "quiz1.php"; //File that the data is being copied from...
        $FileContents = fopen ($FileName, "r"); // open it!
        $FileStep1Str = fread($FileContents, filesize($FileName)); //get the data for writing
        fwrite($FileStep1, $FileStep1Str); //write it!
        fclose ($FileContents); //close it!
        $FileContents = ""; //Clear this var for later use.
        $FileName = ""; //Clear this var for later use.
        echo "index.php was <b>made</b>.<br>\n"; //tell the user!    
        // done!
        // quiz2.php (aka step 2) go!
        /* Basicly how this works is it copies the data from a file
				*  into a string and then writes that string to a different
				*  file in a differnt place.*/
        $FileStep1 = fopen("./saved/$DirName/quiz2.php", "w+"); //File tah twill be written to...
        $FileName = "quiz2.php"; //File that the data is being copied from...
        $FileContents = fopen ($FileName, "r"); // open it!
        $FileStep1Str = fread($FileContents, filesize($FileName)); //get the data for writing
        fwrite($FileStep1, $FileStep1Str); //write it!
        fclose ($FileContents); //close it!
        $FileContents = ""; //Clear this var for later use.
        $FileName = ""; //Clear this var for later use.
        echo "quiz2.php was <b>made</b>.<br>\n"; //tell the user!    
        // done!
        // footer.php go!
        /* Basicly how this works is it copies the data from a file
				*  into a string and then writes that string to a different
				*  file in a differnt place.*/
        $FileStep1 = fopen("./saved/$DirName/footer.php", "w+"); //File tah twill be written to...
        $FileName = "footer.php"; //File that the data is being copied from...
        $FileContents = fopen ($FileName, "r"); // open it!
        $FileStep1Str = fread($FileContents, filesize($FileName)); //get the data for writing
        fwrite($FileStep1, $FileStep1Str); //write it!
        fclose ($FileContents); //close it!
        $FileContents = ""; //Clear this var for later use.
        $FileName = ""; //Clear this var for later use.
        echo "footer.php was <b>made</b>.<br>\n"; //tell the user!    
        // done!
        if ($Store == "Yes") {
            // score.dat go!
            /* Basicly how this works is it copies the data from a file
				*  into a string and then writes that string to a different
				*  file in a differnt place.*/
            $FileStep1 = fopen("./saved/$DirName/score.dat", "w+"); //File that will be written to...
            #$FileName = "score.dat"; //File that the data is being copied from...
            $FileContents = fopen ("score.dat", "r"); // open it!
            $FileStep1Str = fread($FileContents, filesize("score.dat")); //get the data for writing
            fwrite($FileStep1, $FileStep1Str); //write it!
            chmod("./saved/$DirName/score.dat", 0777);
            fclose ($FileContents); //close it!
            $FileContents = ""; //Clear this var for later use.
            #$FileName = ""; //Clear this var for later use.
            echo "score.dat was <b>made</b>.<br>\n"; //tell the user!    
            // done!
        } 

        echo "<b>Done </b> Click <a href=\"./saved/$DirName/\">Here</a> to go to your $Type<br>\n";
    } //All Saves are done.
} 
/****************************************
 ***********END OF MAIN PROGRAM**********
 ****************************************/

?>
  <?php include 'footer.php'?>
</body>
</html>
