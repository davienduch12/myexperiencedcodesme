<br>
<center>
  <p><sub> phpQuest 0.15<br>
    </sub><sub> by <a href="http://www.dynamicdeeds.com/">Max Kaplan</a><br>
    09.06.2003 </sub> </p>
  </center>