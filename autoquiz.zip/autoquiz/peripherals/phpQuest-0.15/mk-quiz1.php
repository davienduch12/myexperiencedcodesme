<html>
<head>
	<title>Max a quiz - Setp 1</title>
</head>
<body>
<form name="Number" method="get" action="mk-quiz2.php">
  <table width="500" border="0" cellspacing="1" cellpadding="1">
    <tr> 
      <td colspan="2"><strong>Step 1:</strong></td>
    </tr>
    <tr> 
      <td width="313">How many <i>questions</i> do you want?</td>
      <td width="71"><input name="Number" type="text" size="4" maxlength="2"></td>
    </tr>
    <tr> 
      <td>What's the <i>maximum</i> number of options you want? </td>
      <td><input name="Options" type="text" id="Options" size="4" maxlength="2"></td>
    </tr>
    <tr> 
      <td>HTML Output, select&quot;Yes&quot; if you wish to have a text area where 
        the user can copy code out of to place what they got on their test. This 
        is great for bloggers, and personal pages.</td>
      <td><select name="HTMLOut">
          <option value="Yes">Yes</option>
          <option value="No">No</option>
        </select></td>
    </tr>
    <tr>
      <td>Store average score on file? This will record what other users have 
        gotten in the past and show the average score of them. Note: If you plan 
        on many people taking your quiz/test you might want to turn this off.</td>
      <td><select name="Store" id="Store">
          <option value="Yes">Yes</option>
          <option value="No">No</option>
        </select></td>
    </tr>
    <tr> 
      <td>Do you want a <em>quiz</em> or a <em>test</em>? The difference is a 
        quiz does not have a percent output but rather a name. A test gives you 
        a percent output and shows the user each question they got right and wrong.</td>
      <td><select name="Type" id="Type">
          <option value="Test">Test</option>
          <option value="Quiz">Quiz</option>
        </select></td>
    </tr>
    <tr> 
      <td colspan="2"><div align="center"></div>
        <div align="center"> 
          <input type="submit" name="Submit" value="Submit">
        </div></td>
    </tr>
  </table>
  </form>
 <?php include 'footer.php'?>
</body>
</html>