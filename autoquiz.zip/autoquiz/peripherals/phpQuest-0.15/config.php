<?php

/**
* Please edit this file.
 **/

$UserName = "a";		//User name for logon into Quest
$Password = "a";		//Password for logon
$Tile = "Title";				//Enter the title of your site
?>