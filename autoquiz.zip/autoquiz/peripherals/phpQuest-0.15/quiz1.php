<html>
<head>
	<?php 
// This is the array(s) that make the questions
require 'include.php';
echo "<title>$Title $Type - Page 1</title>\n";

?>
</head>
<body>
<form name="quiz" method="post" action="quiz2.php">
<?php 
// This is for the loop it pick the array out of $Quiz
$QuestionArray = 0;
echo "<font size=5>$Title $Type</font>\n<br>\n";
echo "$Description\n<br><br>\n"; 
// This will generate the questions
foreach($Quiz as $Question) {
    $QuestionArray = $QuestionArray + 1;
    echo "Question: " . $Quiz[$QuestionArray]['Question'] . "\n<br>\n";

    foreach($Quiz[$QuestionArray]['Options'] as $Option) {
        echo "<input type=\"radio\" name=\"Q$QuestionArray\" value=\"$Option\">";
        echo "$Option\n";
        echo "<br>\n";
    } 
    // Don't worry include.php is used on the next page to...
    echo "<br>\n";
} 

?> 
		<input type="submit" name="Submit" value="Submit">
	</form>
	<br>
	<?php include 'footer.php'?>
</body>
</html>