<?php require '../config.php';
function nl2brConvert($File){		//This will open file and put "<br>" where returns were
	$i = fopen($File, "rb");	//Open file
	echo nl2br(fread($i, filesize($File)));		//Convert breaks to <br> and output
	fclose($i);
}
?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<table width="800" border="1" align="center" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr> 
    <td height="50" colspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr> 
          <td width="800" height="50" align="left" valign="middle"><font size="6">phpQuest 
            <font size="4">Welcome <? echo "$UserName"; ?>!</font> </font></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="150" rowspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr>
          <td height="16" valign="top"><a href="./admin.php?Page=Home">Home</a></td>
        </tr>
        <tr> 
          <td width="150" height="16" valign="top"><a href="../mk-quiz1.php">Generate 
            Quiz/Test</a></td>
        </tr>
        <tr> 
          <td height="16" valign="top"><a href="../saved/edit1.php">Modify</a></td>
        </tr>
        <tr> 
          <td height="16" valign="top"><a href="./admin.php?Page=Help">Help</a></td>
        </tr>
        <tr> 
          <td height="16" valign="top"><a href="./admin.php?Page=Change">Change 
            Log</a></td>
        </tr>
      </table></td>
    <td width="650" height="19" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr> 
          <td width="650" height="18" valign="top"> <font face="Courier New, Courier, mono"> 
            <?php
		  if ($Page == "Help"){
			nl2brConvert("../docs/README.txt");
		  }elseif ($Page == "Change"){
		  	nl2brConvert("../docs/CHANGELOG.txt");
		  }elseif ($Page == "Modify"){
		  	include "../saved/edit1.php";	
		  }elseif ($Page){
		  	nl2brConvert($Page);
		  }else{
		  	nl2brConvert("Home");
		  }
		  ?>
            </font></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td height="19">&nbsp;</td>
  </tr>
</table>
<div align="center"><? include '../footer.php' ?></div>
</body>
</html>
