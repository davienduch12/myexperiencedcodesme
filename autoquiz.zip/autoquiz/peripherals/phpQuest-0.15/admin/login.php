<?php
require("../config.php");		//Get stuff...
if ($inUserName==$UserName && $inPassword==$Password) {
    header('Location: ./admin.php?Page=Home');
}
?>
<html>
<head>
<title>phpQuest - Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body><div align="center">
<div align="center"><font size="6">phpQuest</font> </div>
<form action="./login.php?Page=Login" method="post" name="Login" id="Login">
  <div align="center">
    <table width="300" border="0" cellspacing="0" cellpadding="0">
      <tr> 
        <td width="96">User Name:</td>
        <td width="204"><input name="inUserName" type="text" id="inUserName" size="20">
        </td>
      </tr>
      <tr> 
        <td>Password:</td>
        <td><input name="inPassword" type="password" id="inPassword" size="20">
        </td>
      </tr>
      <tr> 
        <td colspan="2"><div align="center"> 
            <input type="submit" name="Submit" value="Login">
          </div></td>
      </tr>
    </table>
  </div>
</form>

<div align="center">
  <?php include '../footer.php'?>
</div>
</body>
</html>
