<html>
<head>
<title>(Public Release!)</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
	<?php 
// This is just basic error cecking...
if ($Number == "" or $Options == "") {
    echo "<b>Error:</b>I'm sorry but you must enter data for all fields<br>\n";
} elseif ($Number >= 51 or $Number <= 1 or $Options >= 11 or $Options <= 1) {
    if ($Number >= 51) {
        echo "<b>Error: </b>I'm sorry but $Number is to many questions. The maxium is 50<br>\n";
    } 
    if ($Number <= 1) {
        echo "<b>Error: </b>I'm sorry but $Number is to little questions. The minium is 2<br>\n";
    } 
    if ($Options >= 11) {
        echo "<b>Error: </b>I'm sorry but $Options is to many options. The maxium is 10<br>\n";
    } 
    if ($Options <= 1) {
        echo "<b>Error: </b>I'm sorry but $Options is to little options. The minium is 2<br>\n";
    } 
} else { // Go program go!!!
    echo "<form name=\"Question\" method=\"post\" action=\"mk-quiz3.php\">";
	echo "Enter in all your data. Your can use all the HTML tags you want.\n<br>\n<br>\n";
    echo "Title:";
    echo "<input type=\"text\" name=\"Title\">";
    echo "<br>";
    echo "Description: ";
    echo "<input name=\"Description\" type=\"text\" size=\"50\">";
    echo "<br>";
    echo "<br>"; 

    // $g is just a temp var b/c we don't want to fuck up $Number
    $g = $Number;
    while ($g >= 1) {
        $g--;
        $QuestNumber++;
        echo "<table width=\"460\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\">\n";
        echo "<tr>";
        echo "<td width=\"125\">Question #$QuestNumber:</td>\n";
        echo "<td width=\"321\"><input name=\"Quest" . $QuestNumber . "\" type=\"text\" value=\"\" size=\"40\"></td>\n";
        echo "</tr>\n"; 
        // $i is just a temp var b/c we don't want to fuck up $Options
        $i = $Options;
        while ($i >= 1) {
            $i--;
            $OptNumber++;
            echo "<tr>\n";
            echo "<td>&nbsp;&nbsp;&nbsp Option $OptNumber:</td>\n";
            echo "<td><input name=\"Opt" . $QuestNumber . "_" . $OptNumber . "\" type=\"text\" size=\"40\"></td>\n";
            echo "</tr>\n";
        } 
		// Next lines clear temp. var. values...
		$i="";
        $OptNumber = "";
		
        echo "<tr>\n";
        echo "<td>Answer #$QuestNumber:</td>\n";
        echo "<td><select name=\"Ans" . $QuestNumber . "\">\n"; 
        // Ya know whats this is for
        $i = $Options; 
        // This is for the answer you pick the number of the option you want to be the ans.
        while ($i >= 1) {
            $i--;
            $OptNumber++;
            echo "<option value=\"" . $OptNumber . "\">Option: " . $OptNumber . "</option>\n";
        } // while
		// Next lines clear temp. var. values...
		$i="";
        $OptNumber = "";
		
        echo "</select></td>\n";
        echo "</tr>\n";
        echo "</tr>\n";
        echo "</table>\n<br><br>\n";
    }
		
	// Here is the "tpye" stuff...
	if ($Type=="Test") {
	    echo "This will be a <i>test</i>, this means that it will output a percent.<br>\n";
		echo "Output Name: ";
		echo "<input type=\"text\" name=\"Name\">\n<font size=\"1\">Example: \"Pirate\" will output somthing like \"You are 45% pirate!\"</font>\n<br>\n";	
		echo "Note: Leave blank if you want none\n<br><br>\n";
	}elseif ($Type=="Quiz"){	//This is for the rank module, we will use a loop...
		echo "<table width=\"400\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\">";
			echo "<tr>"; 
				echo "<td colspan=\"2\"><strong>Rank: </strong>Enter in the custom titles for each level. </td>";
			echo "</tr>";
			$i="";
			while($i <= 3){		//here is the loop...
				$i++;
				echo "<tr>\n";
	      			echo "<td width=\"64\">Level $i:</td>\n";
	      			echo "<td width=\"329\"><input name=\"RankLvl$i\" type=\"text\" id=\"RankLvl$i\" size=\"40\" maxlength=\"80\"></td>\n";
				echo "</tr>\n";
			} // while
  		echo "</table>\n<br><br>\n";
	}	//end of the rank module

	echo "Directory Name: <input name=\"DirName\" type=\"text\" id=\"DirName\"><br>Note: Remember you can put a spaces but its not requmended especially on *nix systems<br>\n";

	
	// This is needed for the next step in generation...
    echo "<input type=\"hidden\" name=\"Number\" value=\"$Number\">\n";	//Number of questions
	echo "<input type=\"hidden\" name=\"Options\" value=\"$Options\">\n";	//Number of options
	echo "<input type=\"hidden\" name=\"Type\" value=\"$Type\">\n";	//Type of output can be save or export
	echo "<input type=\"hidden\" name=\"HTMLOut\" value=\"$HTMLOut\">\n";	//If they want html for blogges
	echo "<input type=\"hidden\" name=\"Store\" value=\"$Store\">\n";	//If they want to store the scores.
    echo "<input type=\"submit\" name=\"Submit\" value=\"Submit\">\n";
    echo "</form>"; //End of form
} // End of else

?>
<?php include 'footer.php'?>
</body>
</html>
