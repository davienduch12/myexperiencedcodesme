<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<script type="text/javascript" src="scripts/script.js"></script>
<link rel="stylesheet" href="scripts/style.css" type="text/css" />
<?php
	include_once("library/config.php");
	include_once("library/lib.php");
	
	$message = "";
	$status = "true";	// determine if it returns true otherwise false.
	$error = array();
	$action = $_POST["actionflag"];
	$id = $_POST["id"];
	$fname = $_POST["fname"];
	$lname = $_POST["lname"];
	$age = $_POST["age"];
	if(isset($action) || $action == "studentActive") {
		$fname = trim($fname);
		$lname = trim($lname);
		$age = trim($age);
		$fname = mysql_real_escape_string($_POST["fname"]);
		$lname = mysql_real_escape_string($_POST["lname"]);
		$age = mysql_real_escape_string($_POST["age"]);
		$fname = stripslashes($fname);
		$lname = stripslashes($lname);
		$age = stripslashes($age);

		if(empty($fname)) {
			$error["fname"] .= "The first name field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($lname)) {
			$error["lname"] .= "The last name field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($age)) {
			$error["age"] .= "The age field must have a value.<br>\n";	
			$status = "false";
		}
		if(!ereg("^[0-9]{1,2}$",$age)) {
			$error["age"] .= "The age value must be a number.<br>\n";	
			$status = "false";
		}
		if($status == "true") {
			$message = editStudent($id, $fname, $lname, $age);
			#$student_id = $_POST["student_id"] = "";
			$fname = $_POST["fname"] = "";
			$lname = $_POST["lname"] = "";
			$age = $_POST["age"] = "";
		}	
	}
?>
</head>

<body>
<?php
	if($_GET["page"] == "student" || $_POST["SubmitStudent"]) {
		$show_data_student = mysql_query("SELECT * FROM students WHERE student_id='$_GET[id]' LIMIT 1");
		if($show_data_student) {
			while($data = mysql_fetch_array($show_data_student)) {
				$student_id = $data["student_id"];
				$fname = $data["first_name"];
				$lname = $data["last_name"];
				$age = $data["age"];
			}
?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<input name="actionflag" type="hidden" value="studentActive" />
<input name="id" type="hidden" value="<?php echo $student_id;?>" />
  <table border="0" cellspacing="0" cellpadding="4">
    <?php if($message != "") { ?>
    <tr valign="top">
	  <td colspan="3" align="center" bgcolor="#33FF99">
		<?php	echo $message; ?>	  </td>
    </tr>
    <?php } ?>
    <tr>
      <td>First Name of Student: </td>
      <td><input name="fname" type="text" value="<?php echo $fname; ?>" size="35" /></td>
      <td class="error"><?php echo $error["fname"]; ?></td>
    </tr>
    <tr>
      <td>Last Name of Student: </td>
      <td><input name="lname" type="text" value="<?php echo $lname; ?>" size="35" /></td>
      <td class="error"><?php echo $error["lname"]; ?></td>
    </tr>
    <tr>
      <td>Age of Student: </td>
      <td><input name="age" type="text" value="<?php echo $age; ?>" size="2" maxlength="2" /></td>
      <td class="error"><?php echo $error["age"]; ?></td>
    </tr>

    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="SubmitStudent" value="Insert Student Data ko" /></td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
<?php
		}
	}
?>
</body>
</html>