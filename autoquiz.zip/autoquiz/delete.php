<?php
	include_once("library/config.php");
	include_once("library/lib.php");

	if($_GET["page"] == "category") {
		$delete_category = mysql_query("DELETE FROM category WHERE category_id='$_GET[id]' LIMIT 1");
		if(!$delete_category)
			die("Cannot delete the record you requested.<br>\n");
		if($delete_category)
			header("Location: category.php");
	}
	if($_GET["page"] == "question") {
		$delete_question = mysql_query("DELETE FROM question WHERE question_id='$_GET[id]' LIMIT 1");
		if(!$delete_question)
			die("Cannot delete the record you requested.<br>\n");
		if($delete_question)
			$delete_choices = mysql_query("DELETE FROM choices WHERE choice_id='$_GET[id]' LIMIT 1");
			if(!$delete_choices)
				die("Cannot delete the record you requested.<br>\n");
			if($delete_choices)	
				header("Location: question.php");
	}
	if($_GET["page"] == "student") {
		$delete_student = mysql_query("DELETE FROM students WHERE student_id='$_GET[id]' LIMIT 1");
		if(!$delete_student)
			die("Cannot delete the record you requested.<br>\n");
		if($delete_student)
			header("Location: student.php");
	}
	if($_GET["page"] == "questionnaire") {
		$delete_questionnaire = mysql_query("DELETE FROM questionnaire WHERE questionnaire_id='$_GET[id]' LIMIT 1");
		if(!$delete_questionnaire)
			die("Cannot delete the record you requested.<br>\n");
		if($delete_questionnaire)
			header("Location: questionnaire.php");
	}
?>