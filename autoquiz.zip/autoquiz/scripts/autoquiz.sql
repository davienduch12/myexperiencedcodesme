-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 03, 2010 at 06:35 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `autoquiz`
--

-- --------------------------------------------------------

--


use autoquiz;
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(3) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category`, `description`) VALUES
(001, 'noun', 'specify all the naming of all the objects'),
(002, 'verb', 'is an action word'),
(003, 'pronoun', 'is a substitute of a noun '),
(004, 'adjective ', 'it is noun descriptor'),
(005, 'adverb', 'it refers to manner. descriptor of verb');

-- --------------------------------------------------------

--
-- Table structure for table `choices`
--

CREATE TABLE IF NOT EXISTS `choices` (
  `choice_id` int(3) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `choice_1` varchar(50) NOT NULL,
  `choice_2` varchar(50) NOT NULL,
  `choice_3` varchar(50) NOT NULL,
  `choice_4` varchar(50) NOT NULL,
  `answer` varchar(50) NOT NULL,
  PRIMARY KEY (`choice_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `choices`
--

INSERT INTO `choices` (`choice_id`, `choice_1`, `choice_2`, `choice_3`, `choice_4`, `answer`) VALUES
(003, 'noun', 'pronoun', 'adverb', 'adjective', 'noun'),
(004, 'cat ', 'fish', 'monkeys', 'dogs', 'fish'),
(005, 'frogs and fish', 'chickens and birds', 'cats and dogs', 'goats and horses', 'frogs and fish'),
(006, 'gumamela ', 'santol ', 'grass', 'bamoo', 'bamoo'),
(007, 'reads news papers all day', 'cook', 'listen', 'goto neighbor', 'cook'),
(008, ' selling fruits', 'selling rice', 'eating vegatables', 'eating fish', 'selling rice'),
(009, 'cat ', 'horse', 'goat', 'dog', 'goat'),
(010, ' a flower ', 'a pillow ', 'a book', ' a bag', 'a pillow '),
(011, 'grapes ', 'banan', 'santol', 'apple', 'grapes '),
(012, 'book', 'PENCIL', 'Piece of glass', 'white flower', 'Piece of glass');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE IF NOT EXISTS `question` (
  `question_id` int(3) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `question` varchar(150) NOT NULL,
  `category_id` int(3) unsigned zerofill NOT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`question_id`, `question`, `category_id`) VALUES
(003, 'Mam Sarifah is the teacher of english...mam sarif is a noun? ', 001),
(004, '________ hatch from eggs(noun)', 001),
(005, '______ live in ponds.(verb)', 002),
(006, 'of the four plants, below the ___ is the most useful(verb)', 002),
(007, 'fely is teg very busy woman . she is ______.', 003),
(008, ' afarmer earns money by____.(proun)', 003),
(009, 'which of these has a kid?(adj)', 004),
(010, 'which of these can you hug?(adj)', 004),
(011, 'which of these berry family?(adv)', 005),
(012, 'A___ gleams in the light?(adv)', 005);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
