<?php
	include_once("library/lib.php");
	include_once("library/config.php");

	$sql = mysql_query("SELECT * FROM user");
	while($row = mysql_fetch_array($sql)) {
		if($_POST['username'] == $row['username'] && $_POST['password'] == $row['password']) {
			header("Location: category.php");
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	left:345px;
	top:106px;
	width:342px;
	height:227px;
	z-index:1;
	background-image: url(image/login.JPG);
	background-repeat: no-repeat;
}
#Layer2 {
	position:absolute;
	left:488px;
	top:144px;
	width:188px;
	height:177px;
	z-index:2;
}
-->
</style>
</head>

<body background="image/back_all1.png">
<div id="Layer1"></div>


<div id="Layer2">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
  	<td width="15">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Username:</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
	<td><input name="username" type="text" /></td>
  </tr>
  <tr>
    <td colspan="2">Password:</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="password" type="password" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="" type="submit" value="login" /></td>
  </tr>
</table>
</div>

</body>
</html>
