<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>

<body>
<form action="" method="post">
<?php	
define("SP","&nbsp;");
include_once("library/config.php");	
	$result = mysql_query("select * from question");
	$i=0;
	while($data = mysql_fetch_array($result)) {
		echo $data["question"]."<br>";
		$sql = mysql_query("SELECT * FROM choice WHERE choice_id='$data[question_id]'");
		while($row = mysql_fetch_array($sql)) {
			echo " ".SP.SP.SP.SP.SP."<input type=\"radio\" name=\"radio[$i]\" value=\"$row[choice_1]\">".$row["choice_1"]."<br>";
			echo " ".SP.SP.SP.SP.SP."<input type=\"radio\" name=\"radio[$i]\" value=\"$row[choice_2]\">".$row["choice_2"]."<br>";
			echo " ".SP.SP.SP.SP.SP."<input type=\"radio\" name=\"radio[$i]\" value=\"$row[choice_3]\">".$row["choice_3"]."<br>";
			echo " ".SP.SP.SP.SP.SP."<input type=\"radio\" name=\"radio[$i]\" value=\"$row[choice_4]\">".$row["choice_4"]."<br>";
			echo " ".SP.SP.SP.SP.SP."<input type=\"hidden\" name=\"hide[$i]\" value=\"$row[answer]\"><br>";
		}
	$i++;
	}
?>
	<input type="submit" name="submit" value="submit">
</form>

<?php
	$r_array = $_POST[radio];
	$a_array = $_POST[hide];
	$c = 0;
	foreach($r_array as $r) {
		#echo $r."<br>";
		$ch[$c] = $r;
		$c++;
	}
	echo "<br>";
	$b = 0;
	foreach($a_array as $a) {
		#echo $a."<br>";
		$an[$b] = $a;
		$b++;
	}
	for($f=0; $f<count($r_array); $f++) {
		if($ch[$f] == $an[$f]) {
			echo "correct<br>";	
			$correct++; 
		}
		else {
			echo "incorrect<br>";
		}
	}
	echo "you have $correct correct answer";
?>

</body>
</html>
