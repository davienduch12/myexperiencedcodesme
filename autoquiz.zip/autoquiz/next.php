<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php
	include_once("library/lib.php");
	mysql_connect("localhost","root","") or die("Couldn't connect to server");
	mysql_select_db("autoquiz") or die("Couldn't connect to database");
	$result = mysql_query("select * from question");
	$i = 0;
	while($data = mysql_fetch_array($result)) {
		$array[$i] = $data["question_id"];
		$i++;
	}

	#session_start();
	
	if (isset($_POST["counter"])) {
	  $_SESSION["counters"][] = $_POST["counter"];
	  $_SESSION["counter"] = $_POST["counter"]++;
	}
	else {
		$_POST["counter"] = 0;
		$_SESSION["counter"] = 0;
	}
	
/*	if (is_array($_SESSION["counters"])) {
		foreach($_SESSION["counters"] as $count) {
			$show_question = mysql_query("select question from question where question_id='$array[$count]'");	
			while($ques = mysql_fetch_array($show_question)) {
				echo $_GET[id] + 1 .".) ".$ques[question]."<br>\n";
				$show_choices = mysql_query("select * from choice where choice_id='$array[$count]'");					
				while($ans = mysql_fetch_array($show_choices)) {
					echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"Choice[$count]\" type=\"radio\" value=\"$ans[choice_1]\" />".$ans[choice_1]."<br>\n";
					echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"Choice[$count]\" type=\"radio\" value=\"$ans[choice_2]\" />".$ans[choice_2]."<br>\n";
					echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"Choice[$count]\" type=\"radio\" value=\"$ans[choice_3]\" />".$ans[choice_3]."<br>\n";
					echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"Choice[$count]\" type=\"radio\" value=\"$ans[choice_4]\" />".$ans[choice_4]."<br>\n";
					echo "<input name=\"CorrectAns[$count]\" type=\"hidden\" value=\"$ans[answer]\" /><br>\n";
				}
			}
			$handleChoice[$count];
		}
	}*/
?>

<form action="next.php?id=<?php echo $_POST[counter];?>" method="post">
	<input name="counter" type="hidden" value="<?php echo $_POST[counter]; ?>" />
	<?php
		if (is_array($_SESSION["counters"])) {
			foreach($_SESSION["counters"] as $count) {
				$show_question = mysql_query("select question from question where question_id='$array[$count]'");	
				while($ques = mysql_fetch_array($show_question)) {
					echo $_GET[id] + 1 .".) ".$ques[question]."<br>\n";
					$show_choices = mysql_query("select * from choice where choice_id='$array[$count]'");					
					while($ans = mysql_fetch_array($show_choices)) {
						echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"Choice[$count]\" type=\"radio\" value=\"$ans[choice_1]\" />".$ans[choice_1]."<br>\n";
						echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"Choice[$count]\" type=\"radio\" value=\"$ans[choice_2]\" />".$ans[choice_2]."<br>\n";
						echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"Choice[$count]\" type=\"radio\" value=\"$ans[choice_3]\" />".$ans[choice_3]."<br>\n";
						echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"Choice[$count]\" type=\"radio\" value=\"$ans[choice_4]\" />".$ans[choice_4]."<br>\n";
						echo "<input name=\"CorrectAns[$count]\" type=\"hidden\" value=\"$ans[answer]\" /><br>\n";
					}
				}
				$handleChoice[$count];
			}
		}

	if($_GET["id"] < 14) {
		echo "<input name=\" \" type=\"submit\" value=\" NEXT \" />";
	}
	?>
</form> 
</body>
</html>