<?php
	session_start();
	include("library/config.php");
	include("library/lib.php");
	$student_id = $_POST["student_id"];
	$question_code = $_POST["question_code"];
	if(getRow("students","student_id", $_POST["student_id"]) && getRow("questionnaire","questionnaire_id", $_POST["question_code"])) {
		$_SESSION["student"] = $student_id;
		$_SESSION["questionnaire"] = $question_code;
		header("Location: answersheet2.php");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>home</title>
<link rel="stylesheet" href="scripts/style.css" type="text/css" />
<script type="text/javascript" src="scripts/script.js"></script>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body background="image/back_all1.png" onload="MM_preloadImages('image/home_btn_over.jpg','image/quiz_btn_over.jpg','image/exam_btn_over.jpg','image/student_btn_over.jpg','image/score_btn_over.jpg','image/logIn_btn_over.jpg')">
<table width="800" align="center" border="0" cellspacing="0" cellpadding="0">
  <tr align="center">
    <td><img src="image/image_final_02.jpg" width="100%" height="200" /></td>
  </tr>
  <tr>
    <td><table width="100%" background="image/bg_02.jpg" border="0" cellspacing="0" cellpadding="0">
	  <tr bgcolor="#53BC17" align="center" valign="middle">
		<td><img src="image/image_final_11.jpg" /></td>
		<td><a href="index.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image20','','image/home_btn_over.jpg',1)"><img src="image/image_final_13.jpg" name="Image20" width="120" height="59" border="0" id="Image20" /></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="studentquiz.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image21','','image/quiz_btn_over.jpg',1)"><img src="image/image_final_15.jpg" name="Image21" width="120" height="59" border="0" id="Image21" /></a><a href="quiz.htm"></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="studentexam.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image22','','image/exam_btn_over.jpg',1)"><img src="image/image_final_04.jpg" name="Image22" width="120" height="60" border="0" id="Image22" /></a><a href="exam.htm"></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="studentlist.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image23','','image/student_btn_over.jpg',1)"><img src="image/image_final_06.jpg" name="Image23" width="120" height="60" border="0" id="Image23" /></a><a href="#"></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="score.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image24','','image/score_btn_over.jpg',1)"><img src="image/image_final_08.jpg" name="Image24" width="120" height="60" border="0" id="Image24" /></a><a href="#"></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="login.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image25','','image/logIn_btn_over.jpg',1)"><img src="image/image_final_10.jpg" name="Image25" width="120" height="60" border="0" id="Image25" /></a><a href="#"></a></td>
		<td><img src="image/image_final_11.jpg" /></td>
	  </tr>
	  <tr>
	  	<td>&nbsp;</td>
	  	<td colspan="11">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  <tr valign="middle" height="10">
				<td width="10"><img src="image/left_curve.gif" /></td>
				<td width="*" background="image/top_edge.gif"></td>
				<td width="10"><img src="image/right_curve.gif" /></td>
			  </tr>
			  <tr bgcolor="#FFFFFF">
				<td background="image/left_edge.gif"></td>
				<td background="image/notebook_exam.jpg" height="450" valign="top">
				<br /><br /><br />
				<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
					<input name="actionflag" type="hidden" value="login" />
					<table align="center" width="55%" border="0" cellspacing="0" cellpadding="0">
					  <tr>
						<td>
						<table width="100%" border="0" cellspacing="0" cellpadding="4">
						  <tr>
							<td colspan="2">&nbsp;</td>
							</tr>
						  <tr>
							<td align="right">Enter Student ID: </td>
							<td><input name="student_id" type="text" id="student_id" /></td>
						  </tr>
						  <tr>
							<td align="right">Enter Questionnaire Code: </td>
							<td><input name="question_code" type="text" id="question_code" /></td>
							</tr>
						  <tr>
							<td colspan="2" align="center"><input type="submit" name="Submit" value="Log In" /></td>
							</tr>
						</table>
						</td>
					  </tr>
					</table>
					</form>
				</td>
				<td background="image/right_edge.gif">&nbsp;</td>
			  </tr>
			  <tr>
				<td><img src="image/left_curve_below.gif" /></td>
				<td background="image/below_edge.gif"></td>
				<td><img src="image/right_curve_below.gif" /></td>
			  </tr>
			  <tr height="30">
				<td>&nbsp;</td>
				<td>
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="footer">
				  <tr align="center" valign="middle">
					<td><a href="#">&bull;our home</a></td>
					<td><a href="#">&bull;quiz</a></td>
					<td><a href="#">&bull;exam</a></td>
					<td><strong>&copy;Dream Team 2010</strong></td>
					<td><a href="#">&bull;student</a></td>
					<td><a href="#">&bull;score</a></td>
					<td><a href="#">&bull;log-in</a></td>
				  </tr>
				</table></td>
				<td>&nbsp;</td>
			  </tr>
			</table>
		  </td>
		<td>&nbsp;</td>
	  </tr>
	</table>
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>

</body>
</html>
