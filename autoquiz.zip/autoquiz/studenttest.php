<?php
	session_start();
	include("library/config.php");
	include("library/lib.php");
	$student_id = $_POST["student_id"];
	$question_code = $_POST["question_code"];
	if(getRow("students","student_id", $_POST["student_id"]) && getRow("questionnaire","questionnaire_id", $_POST["question_code"])) {
		$_SESSION["student"] = $student_id;
		$_SESSION["questionnaire"] = $question_code;
		header("Location: answersheet.php");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input name="actionflag" type="hidden" value="login" />
<table align="center" width="55%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td>
	<table width="100%" border="0" cellspacing="0" cellpadding="4">
	  <tr>
		<td colspan="2">&nbsp;</td>
		</tr>
	  <tr>
		<td align="right">Enter Student ID: </td>
		<td><input name="student_id" type="text" id="student_id" /></td>
	  </tr>
	  <tr>
	    <td align="right">Enter Questionnaire Code: </td>
	    <td><input name="question_code" type="text" id="question_code" /></td>
	    </tr>
	  <tr>
		<td colspan="2" align="center"><input type="submit" name="Submit" value="Log In" /></td>
		</tr>
	</table>
	</td>
  </tr>
</table>
</form>
</body>
</html>