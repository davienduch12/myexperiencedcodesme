<?php
	mysql_connect("localhost","root","klg") or die("Couldn't connect to server");
	mysql_select_db("autoquiz") or die("Couldn't connect to database");
	$result = mysql_query("select * from question");
	$i = 0;
	while($data = mysql_fetch_array($result)) {
		$array[$i] = $data["question"];
		$i++;
	}

	session_start();
	
	if (isset($_POST["word"])) {
	  $_SESSION["words"][] = $_POST["word"];
	  $_SESSION["word"] = $_POST["word"]++;
	}
	else {
		$_POST["word"] = 0;
		$_SESSION["word"] = 0;
	}
	
	if (is_array($_SESSION["words"])) {
	  foreach($_SESSION["words"] as $word) {
		echo $array[$word] . "<br>";
	  }
	}
?>
<FORM ACTION="index2.php" METHOD=POST>
Enter a word: <INPUT type="hidden" NAME="word" value="<?php echo $_POST['word'];?>">
<INPUT TYPE=SUBMIT VALUE="Add word to list">
</FORM>