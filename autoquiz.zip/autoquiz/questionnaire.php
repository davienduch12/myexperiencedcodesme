<?php
	session_start();
	include_once("library/config.php");
	include_once("library/lib.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>CreateQuestionnaire</title>
<link rel="stylesheet" href="scripts/style.css" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 10px;
	font-weight: bold;
}
-->
</style>
<script type="text/javascript" src="scripts/script.js"></script>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<?php
	require_once("library/config.php");
	require_once("library/lib.php");
	$message = "";
	$status = "true";	// determine if it returns true otherwise false.
	$error = array();
	$action = $_POST["actionflag"];
	$category = $_POST["category"];
	$question = $_POST["question"];
	$choice1 = $_POST["choice1"];
	$choice2 = $_POST["choice2"];
	$choice3 = $_POST["choice3"];
	$choice4 = $_POST["choice4"];
	$choiceGroup = $_POST["choiceGroup"];
	if(isset($action) || $action == "questionActive") {
		$category = trim($category);
		$question = trim($question);
		$choice1 = trim($choice1);
		$choice2 = trim($choice2);
		$choice3 = trim($choice3);
		$choice4 = trim($choice4);
		
		$category = mysql_real_escape_string($_POST["category"]);
		$question = mysql_real_escape_string($_POST["question"]);
		$choice1 = mysql_real_escape_string($_POST["choice1"]);
		$choice2 = mysql_real_escape_string($_POST["choice2"]);
		$choice3 = mysql_real_escape_string($_POST["choice3"]);
		$choice4 = mysql_real_escape_string($_POST["choice4"]);
		
		$category = stripslashes($category);
		$question = stripslashes($question);
		$choice1 = stripslashes($choice1);
		$choice2 = stripslashes($choice2);
		$choice3 = stripslashes($choice3);
		$choice4 = stripslashes($choice4);
		
		if(empty($category)) {
			$error["category"] .= "The category field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($question)) {
			$error["question"] .= "The question field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($choice1)) {
			$error["choice1"] .= "The first choice field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($choice2)) {
			$error["choice2"] .= "The second choice field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($choice3)) {
			$error["choice3"] .= "The third choice field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($choice4)) {
			$error["choice4"] .= "The fourth choice field must have a value.<br>\n";	
			$status = "false";
		}
		if(empty($choiceGroup)) {
			$error["choiceGroup"] .= "You must choose the correct answer.<br>\n";
			$status = "false";
		}
		if(getRow("question", "question", $question)) {
			$error["question"] .= "Question '$question' already exists. Try another one.<br>\n";
			$status = "false";
		}
		if(!empty($choiceGroup)) {
			switch($choiceGroup) {
				case 'A':
					$answer = $choice1;
					break;
				case 'B':
					$answer = $choice2;
					break;
				case 'C':
					$answer = $choice3;
					break;
				case 'D':
					$answer = $choice4;
					break;
			}
		}
		if($status == "true") {
			$message = addQuestion($question, $category, $choice1, $choice2, $choice3, $choice4, $answer);
			#$category = $_POST["category"] = "";
			$question = $_POST["question"] = "";
			$choice1 = $_POST["choice1"] = "";
			$choice2 = $_POST["choice2"] = "";
			$choice3 = $_POST["choice3"] = "";
			$choice4 = $_POST["choice4"] = "";
			$answer = "";
		}	
	} // end of actionflag....
?>
<body background="image/back_all1.png" onload="MM_preloadImages('image/home_btn_over.jpg','image/quiz_btn_over.jpg','image/exam_btn_over.jpg','image/student_btn_over.jpg','image/score_btn_over.jpg','image/logIn_btn_over.jpg')">
<table width="800" align="center" border="0" cellspacing="0" cellpadding="0">
  <tr align="center">
    <td><img src="image/image_final_02.jpg" width="100%" height="200" /></td>
  </tr>
  <tr>
    <td><table width="100%" background="image/bg_02.jpg" border="0" cellspacing="0" cellpadding="0">
	  <tr bgcolor="#53BC17" align="center" valign="middle">
		<td><img src="image/image_final_11.jpg" /></td>
		<td><a href="category.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image20','','image/home_btn_over.jpg',1)"><img src="image/create category .jpg" width="124" height="67" border="0" /></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="question.php"><img src="image/create exam .jpg" width="124" height="67" border="0" /></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="questionnaire.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image22','','image/exam_btn_over.jpg',1)"><img src="image/create quiz .jpg" width="124" height="67" border="0" /></a><a href="exam.htm"></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="student.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image23','','image/student_btn_over.jpg',1)"><img src="image/settings.jpg" width="124" height="67" border="0" /></a><a href="#"></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="reportadmin.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image24','','image/score_btn_over.jpg',1)"><img src="image/report.jpg" width="124" height="67" border="0" /></a><a href="#"></a></td>
		<td><img src="image/image_final_05.jpg" width="3" height="60" /></td>
		<td><a href="index.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image25','','image/logIn_btn_over.jpg',1)"><img src="image/log_out.jpg" width="124" height="67" border="0" /></a><a href="#"></a></td>
		<td><img src="image/image_final_11.jpg" /></td>
	  </tr>
	  <tr>
	  	<td>&nbsp;</td>
	  	<td colspan="11">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  <tr valign="middle" height="10">
				<td width="10"><img src="image/left_curve.gif" /></td>
				<td width="*" background="image/top_edge.gif"></td>
				<td width="10"><img src="image/right_curve.gif" width="10" height="10" /></td>
			  </tr>
			  <tr bgcolor="#FFFFFF">
				<td background="image/left_edge.gif"></td>
				<td><table align="center" width="50%" border="0" cellspacing="4" bgcolor="#CCCCCC" cellpadding="0">
				  <tr>
					<td>
					<table width="100%" border="0" cellspacing="2" bgcolor="#FFFFFF" cellpadding="2">
					  <tr>
						<td colspan="2" bgcolor="#55FF55" align="center"><strong style="color:#330099">Q- Panel </strong></td>
					  </tr>
					  <tr>
						<th>Category</th>
						<th>Available Questions</th>
					  </tr>
					  <?php
						$show_category = mysql_query("SELECT * FROM category");
						while($show = mysql_fetch_array($show_category)) {
							echo "<tr align=center>";
							$show_total = mysql_query("SELECT DISTINCT COUNT(category_id) as total FROM question WHERE category_id='$show[category_id]' AND flag='0' ");
							while($content = mysql_fetch_array($show_total)) {
								echo "<td>".$show["category"]."</td>";
								echo "<td>".$content["total"]."</td>";
							}
							echo "</tr>";
						}
						$get_total = mysql_query("SELECT COUNT(category_id) as availableQ FROM question WHERE flag='0'");
						while($get_result = mysql_fetch_array($get_total)) { 
							$_SESSION["totalQ"] = $get_result[availableQ];
							echo "<tr>";
								echo "<td colspan=2 align=center><hr size=1>TOTAL QUESTIONS AVAILABLE: $get_result[availableQ]</td>";
							echo "</tr>";
						}
					  ?>
					</table>
					</td>
				  </tr>
				</table>
				<br /><br />
				<?php
					$message = "";
					$action = $_POST["actionflag"];
					$status = "true";
					$error = array();
					$qcode = $_POST["qcode"];
					$qno = $_POST["qno"];
					if(isset($action) || $action == "questionnaire") {
						if(empty($qcode)) {
							$error["qcode"] .= "The Questionnaire Code must have a value.<br>\n";
							$status = "false";
						}
						if(empty($qno)) {
							$error["qno"] .= "The Total Question Field must have a value.<br>\n";
							$status = "false";
						}	 
						if(strlen($qcode) < 6) {
							$error["qcode"] .= "Must be at least 6 characters.<br>\n";
							$status = "false";
						}	
						if(!ereg("^[0-9]{1,3}$", $qno)) {
							$error["qno"] .= "Must be a number.<br>\n";
							$status = "false";
						}
						if($qno > $_SESSION["totalQ"]) {
							$error["qno"] .= "No. of question(s) must be equal or less than the total of available question(s).<br>\n";
							$status = "false";
						}
						if(getRow("questionnaire", "questionnaire_id", $qcode)) {
							$error["qcode"] .= "Questionnaire Code '$qcode' already exists. Try another one.<br>\n";
							$status = "false";
						}
						if($status == "true") {
							$message = addQuestionnaire($qcode, $qno);
							$qcode = $_POST["qcode"] = "";
							$qno = $_POST["qno"] = "";
						}
					}
				?>
				<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
				<input name="actionflag" type="hidden" value="questionnaire" />
				<table align="center" width="98%" border="0" cellspacing="2" cellpadding="4">
				  <tr>
					<td colspan="2"><strong style="font-size:14px">Making Questionnaire:</strong>
					  <hr /></td>
				  </tr> 
				  <?php if($message != "") { ?>
				  <tr valign="top">
					<td colspan="4" align="center" bgcolor="#33FF99">
						<?php	echo $message; ?>
					</td>
				  </tr>
				  <?php } ?>
				  <tr>
					<td align="center">Enter the Questionnaire Code:&nbsp;&nbsp;
					  <input name="qcode" type="text" id="qcode" value="<?php echo $_POST["qcode"]; ?>" size="12" maxlength="12" />
					  &nbsp;
					  <span class="style1">(must be 6-12 characters)</span></td>
					<td class="error"><?php echo $error["qcode"];?></td>
				  </tr>
				  <tr align="center">
					<td>Enter the total number of question(s) to create:&nbsp;&nbsp;<input name="qno" type="text" id="qno" value="<?php echo $_POST["qno"]; ?>" size="2" maxlength="3" />
				&nbsp; <span class="style1">(maximum of 3 integers)</span></td>
					<td class="error"><?php echo $error["qno"];?></td>
				  </tr>
				  <tr>
					<td align="center" colspan="2"><input name="SubmitQuestionnaire" type="submit" id="SubmitQuestionnaire" value="Submit" /></td>
				  </tr>
				</table>
				</form>
				<br />
				<table align="center" width="95%" border="0" cellspacing="2" cellpadding="2" class="content">
				  <tr>
					<th>Questionnaire Code: </th>
					<th>Total</th>
					<th>Edit</th>
					<th>Delete</th>
				  </tr>
				<?php
					$tbl = "questionnaire";
					$count = 1;		// responsible for alternate colors of rows.
				
					$sql = "SELECT * FROM $tbl";
					$result = mysql_query($sql);
					if (!$result) {
						die("writeTableList fatal error: ".mysql_error());
						return false;
					}
					while ($row = mysql_fetch_row($result)) {	// returning an array containing each field in the row
						if($count%2 == 0)
							$bgcolor = "#E7E7E7";
						else
							$bgcolor = "#F5F5F5";
						echo "<tr bgcolor='$bgcolor' onmouseover='this.style.background=\"#CEFFCE\"' onmouseout='this.style.background=\"$bgcolor\"'>";
						for ($i = 0; $i < count($row); $i++)
						  echo " <td align=center>$row[$i]</td> ";
						  echo " <td align=center><a href=\"edit_questionnaire.php?page=questionnaire&id=$row[0]\">edit</a></td> ";
						  echo " <td align=center><a href=\"delete.php?page=questionnaire&id=$row[0]\" onClick=\"if (!confirm('Do you really want to delete this record?')) return false;\">delete</a></td> ";	
						echo "</tr>";
						$count++;
					}
				
				?>
				</table>
				</td>
				<td background="image/right_edge.gif">&nbsp;</td>
			  </tr>
			  <tr>
				<td><img src="image/left_curve_below.gif" /></td>
				<td background="image/below_edge.gif"></td>
				<td><img src="image/right_curve_below.gif" /></td>
			  </tr>
			  <tr height="30">
				<td>&nbsp;</td>
				<td>
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="footer">
				  <tr align="center" valign="middle">
					<td><a href="#">&bull;our home</a></td>
					<td><a href="#">&bull;quiz</a></td>
					<td><a href="#">&bull;exam</a></td>
					<td><strong>&copy;Dream Team 2010</strong></td>
					<td><a href="#">&bull;student</a></td>
					<td><a href="#">&bull;score</a></td>
					<td><a href="#">&bull;log-in</a></td>
				  </tr>
				</table></td>
				<td>&nbsp;</td>
			  </tr>
			</table>
		  </td>
		<td>&nbsp;</td>
	  </tr>
	</table>
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>

</body>
</html>
